from isaacsim import SimulationApp
app = SimulationApp({"headless": True})
import numpy as np
from isaacsim.core.api import World
from isaacsim.core.api.objects import DynamicCuboid, GroundPlane
from isaacsim.sensors.camera import Camera
from pxr import Sdf, UsdLux
import omni.usd

w = World(stage_units_in_meters=1.0)
stage = omni.usd.get_context().get_stage()
GroundPlane("/World/ground")
DynamicCuboid("/World/box", position=np.array([0.0, 0.0, 0.5]),
              scale=np.array([1.0, 1.0, 1.0]), color=np.array([1.0, 0.2, 0.2]))

# two light flavours, so we can tell which (if either) reaches the renderer
dome = stage.DefinePrim("/World/sky", "DomeLight")
dome.CreateAttribute("inputs:intensity", Sdf.ValueTypeNames.Float).Set(1000.0)
dist = stage.DefinePrim("/World/sun", "DistantLight")
dist.CreateAttribute("inputs:intensity", Sdf.ValueTypeNames.Float).Set(3000.0)

cam = Camera("/World/cam", resolution=(640, 480))
w.reset()
cam.initialize()
cam.set_world_pose(np.array([4.0, 4.0, 3.0]),
                   np.array([0.354, 0.146, 0.354, 0.854]), camera_axes="usd")

for n in (10, 60, 150):
    while getattr(cam, "_n", 0) < n:
        w.step(render=True)
        cam._n = getattr(cam, "_n", 0) + 1
    f = np.asarray(cam.get_rgba())
    rgb = f[:, :, :3] if f.ndim == 3 else f
    print(f"RESULT steps={n} shape={f.shape} min={rgb.min()} max={rgb.max()} mean={rgb.mean():.2f}",
          flush=True)
app.close()

# H1 loco-manipulation in Isaac Sim — research digest

Salvaged from workflow run `wf_b40b0ff0-9e6` (killed by OOM mid-verify).
40 sources fetched → 218 claims → **only 17 reached adversarial verification, 12 of
those refuted for overreach**. So: the *sources* are real and were read, but outside
the 5 verified items below, treat everything as a strong lead, not a settled fact.

## Bottom line

1. **Nobody manipulates with a plain 19-DoF H1.** Every serious project either
   switches robot (G1 / H1-2) or bolts on hardware. Our setup is off the beaten path
   by construction, not by mistake.
2. **Pinning the base during the pick is accepted upstream practice**, not a hack —
   NVIDIA ships a fixed-base variant of its own pick-place task. Our `ponytail:` pin
   is defensible; keep it.
3. **Attach-on-contact is first-class and endorsed by an Isaac Lab maintainer** over
   friction grasping. This is the shortest path to a working `--stage demo`.
4. **The friction-grasp knobs that matter are collider-level, not friction-level** —
   SDF collision, contact/rest offset, compliant contact. One forum thread reports
   friction/mass/gain tuning explicitly failing to stop slippage.
5. **Training is cheap enough to be real** (~1.4–3 h on one GPU) — but no published
   H1 loco-manip policy exists to fine-tune from.

---

## Q1 · What do people attach to H1's hand-less forearm?

- ✅ **VERIFIED** — Isaac Sim 4.5's asset pack ships **`Robots/Unitree/H1/h1_with_hand.usd`**
  next to the `h1.usd` we use. Arms terminate in `left_hand_link` / `right_hand_link`.
  [asset catalog](https://docs.isaacsim.omniverse.nvidia.com/4.5.0/assets/usd_assets_robots.html)
- There **is** a published official mount transform: Unitree's `h1_with_hand.urdf`
  adds a wrist **ROLL** joint (`right_hand_joint`) as a child of `right_elbow_link`,
  **0.2605 m along the forearm**, axis `1 0 0`, ±3.054 rad, effort 6 N·m. The hand
  itself attaches with a plain fixed joint (`origin xyz 0.003 0 0, rpy 0 0 1.5708`).
  [unitree_ros](https://github.com/unitreerobotics/unitree_ros/blob/master/robots/h1_description/urdf/h1_with_hand.urdf)
  — *This is a directly usable number for our `GRIP_MOUNT_X = 0.255`.*
- Even the official hand variant is only **5 DoF per arm** (4 + wrist roll). Roll is
  the one axis a top-down pinch doesn't need. **Orientation stays unsolvable.**
- Unitree publishes **no parallel-jaw gripper** for H1 — the only factory option is a
  5-finger Inspire-style hand.
- ✅ **VERIFIED** — Isaac Sim ships a **Robot Assembler** extension
  (`RobotAssembler.assemble_articulations`) as the sanctioned way to bolt a gripper
  onto an arm. `single_robot=True` merges both into one articulation.
  [docs](https://docs.isaacsim.omniverse.nvidia.com/4.5.0/robot_setup/assemble_robots.html)
  — *A verifier explicitly refuted the stronger claim that this reproduces our DoF
  renumbering; that remains unconfirmed either way.*
- Standalone parallel-jaw gripper USDs exist as separate assets (Robotiq 2F-85 at
  `Robots/Robotiq/2F-85/Robotiq_2F_85_edit.usd`), but NVIDIA documents **no procedure**
  for mounting one on a humanoid.
- Our own 4-DoF problem is a known NVIDIA-forum issue: **Lula IK fails to converge on
  H1 purely because the arm is 4-DoF**, and its usable workspace under Lula is tiny.
  [forum](https://forums.developer.nvidia.com/t/lula-kinematics-solver-doesnt-converge-with-unitree-h1/310394)

## Q2 · Base stability during manipulation

Four distinct answers in the literature, in ascending cost:

| Approach | Who | Notes |
|---|---|---|
| **Pin the base** | Isaac Lab upstream | `fix_root_link=True` in `ArticulationRootPropertiesCfg`. NVIDIA's own G1 pick-place config pins the floating base; a fixed-base task variant ships. [PR 3242](https://github.com/isaac-sim/IsaacLab/pull/3242), [disc 1619](https://github.com/isaac-sim/IsaacLab/discussions/1619) |
| **Split control** | Isaac Lab [PR 3150](https://github.com/isaac-sim/IsaacLab/pull/3150) | Pre-trained RL lower body takes `(vx,vy,wz,height)`; arm IK on top. Needed a new primitive, `PinkKinematicsConfiguration`. |
| **Decoupled dual-agent RL** | [FALCON](https://arxiv.org/abs/2505.24198) | Separate upper/lower agents, co-trained with a force curriculum. Claims **2–5× less arm-induced disturbance** than whole-body RL. |
| **Single co-trained WBC** | [HOMIE](https://homietele.github.io/), [OmniH2O](https://arxiv.org/html/2406.08858), [ExBody](https://arxiv.org/html/2402.16796v1) | One policy for all 19 joints. OmniH2O trains station-keeping in by **dataset augmentation**, not runtime command. |

Reality check on IK precision: even with a **fixed base** and DLS differential IK, a
reported steady-state end-effector error was **~3 cm** — larger than our ~2 cm grasp
tolerance. Pinning alone does not buy precision.

## Q3 · Grasp stability in PhysX

**The endorsed shortcut** — ✅ **VERIFIED**: `isaacsim.robot.surface_gripper` ships
enabled by default. It does **not simulate jaw friction at all**; it creates a
dynamic joint on contact. Tunable `ShearForceLimit` / `CoaxialForceLimit` break
thresholds, and `MaxGripDistance` capture radius + retry window — so it's a
force-limited attach, not an unbreakable weld.
[docs](https://docs.isaacsim.omniverse.nvidia.com/5.1.0/robot_simulation/ext_isaacsim_robot_surface_gripper.html)
An **Isaac Lab maintainer explicitly endorses attach-on-contact over friction
grasping** for grasp-like tasks. Isaac Lab 2.3 adds surface-gripper support to
manager-based envs.

**If you hand-roll the attach**: a runtime `UsdPhysics.FixedJoint` works on CPU PhysX
but **snaps bodies to their init poses on the GPU pipeline**. The maintainer-prescribed
fix is `PhysxSchema.PhysxPhysicsAttachment.Define()` + `PhysxAutoAttachment`, confirmed
working by the original reporter. [disc 4189](https://github.com/isaac-sim/IsaacLab/discussions/4189)

**If you keep real friction**, the knobs that reportedly matter:
- **SDF collision** resolved both grasp instability and clipping for a Robotiq gripper.
  [forum](https://forums.developer.nvidia.com/t/challenges-with-robotiq-3f-gripper-in-isaac-sim-object-slippage-and-clipping/294468)
- **Convex hull is the default** for mesh geometry, and triangle-mesh is **silently
  rejected on dynamic bodies** → fat hull that ejects grasped objects. One thread's
  accepted answer to "gripper won't close on the cube" was *purely* switching collider
  approximation. [disc 2651](https://github.com/isaac-sim/IsaacLab/discussions/2651)
- **Contact Offset vs Rest Offset** are the documented knobs for thin/small geometry.
  Rest offset inflates the effective geometry; contact offset only affects detection.
- **Compliant (spring-damper) contact** is NVIDIA-recommended for exactly this.
- ⚠️ Directly relevant to us: one poster reports **friction/mass/joint-gain tuning
  alone did NOT stop slippage** (tried 1.0/1.0 gripper vs 0.5 object).

**Grasp Editor** (`isaacsim.robot_setup.grasp_editor`, 4.5) authors grasps offline and
validates them by an **applied external force/torque escape test**. But the workflow is
**fundamentally 6-DoF** — it stores a full orientation quaternion — so it does not fit
a wristless arm.

## Q4 · Existing repos

| Project | Robot | Verdict for us |
|---|---|---|
| [IsaacLab PR 3150](https://github.com/isaac-sim/IsaacLab/pull/3150) / `Isaac-PickPlace-Locomanipulation-G1-Abs-v0` | G1 + Dex3 | Closest reference. **Isaac Lab 2.3 / Isaac Sim 5.1** — not our 4.5 pip env. |
| [IsaacLab-Arena](https://github.com/isaac-sim/IsaacLab-Arena) | G1, Franka, GR1, Allegro | Has a walk-pick-carry example. **H1 absent.** Needs Isaac Lab 3.0 / Sim 6.0 / py≥3.12. |
| [unitree_sim_isaaclab](https://github.com/unitreerobotics/unitree_sim_isaaclab) | G1-29, H1-2-27 | ✅ VERIFIED: **plain 19-DoF H1 not supported.** Walk-then-pick only for G1. |
| [HOVER](https://isaac-sim.github.io/IsaacLab/main/source/policy_deployment/00_hover/hover_policy.html) | **H1** ✔ | NVIDIA's documented WBC for H1 — but motion *tracking*, **not manipulation**. |
| [FALCON](https://github.com/LeCAR-Lab/FALCON) | G1, Booster T1 | **No H1.** And uses a `fakehand` abstraction — no real gripper. |
| [HumanPlus](https://github.com/MarkFzp/humanplus) | H1 | Bolted a **custom 1-DoF Dynamixel wrist** on. Isaac **Gym**, not Sim/Lab. |
| OmniH2O | H1 | Physically retrofits **Inspire hands**. Grasping never simulated. |
| ExBody | H1 | **Zero manipulation** — object interaction filtered out of training data. |

## Q5 · Training cost by GPU

| Source | Setup | Cost |
|---|---|---|
| [HOMIE](https://homietele.github.io/) | single **consumer** GPU | **~3 h** wall clock ← most encouraging datapoint |
| [Arm/DGX Spark tutorial](https://learn.arm.com/learning-paths/laptops-and-desktops/dgx_spark_isaac_robotics/4_isaac_rfl/) | 4096 envs, 1500 iters (H1 locomotion default) | ~66k steps/s; **ETA 01:21:49** for 3000 iters |
| FALCON | IsaacGym, 4096 envs | ~6000 PPO iterations |
| HOVER teacher | 1024 envs | 10M iterations (manually terminated) |

Practical env range quoted: **2048–4096**. Nothing in the salvaged set gives a
per-GPU-tier VRAM breakdown — that gap is why the re-run asks for it explicitly.

---

## What this changes for us

- **Keep the pin.** Upstream does the same thing. Stop treating it as debt.
- **Switch the grasp to attach-on-contact** for the shippable demo. Force-limited, so
  it still looks and behaves like a grip. Keep the friction grasp behind `--no-gripper`
  style flag as the "real physics" variant.
- **`h1_with_hand.usd` is worth 20 minutes** — a real wrist roll at a documented
  0.2605 m mount, versus our hand-authored fingers at `GRIP_MOUNT_X = 0.255`.
- **Don't train anything yet.** No H1 loco-manip policy exists to start from, and
  training doesn't fix a gripper that extrudes the cube.

## Caveats

- 12 of 17 verified claims were **refuted for overreach** — verifiers were harsh, and
  several read the *installed* 4.5 source on workstation-1 rather than trusting docs.
  The 201 unverified claims have had no such scrutiny.
- Several primary citations are **4.2.0 or 5.1.0 doc pages**, not 4.5 — surface gripper
  details in particular. Confirm against the local install before relying on them.
- Two of the most useful repos are gated behind **Isaac Sim 5.1 / 6.0**. Adopting them
  is a version migration, not an import.

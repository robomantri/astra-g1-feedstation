#!/usr/bin/env bash
# Provision workstation-1 for the H1 demo. Idempotent: safe to re-run.
set -euo pipefail

CONDA_DIR="$HOME/miniforge3"
ENV_NAME="h1sim"

if [ ! -x "$CONDA_DIR/bin/conda" ]; then
    echo ">>> installing miniforge"
    curl -fsSL -o /tmp/miniforge.sh \
        "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh"
    bash /tmp/miniforge.sh -b -p "$CONDA_DIR"
fi
source "$CONDA_DIR/etc/profile.d/conda.sh"

if ! conda env list | grep -q "^$ENV_NAME "; then
    echo ">>> creating env $ENV_NAME"
    conda create -n "$ENV_NAME" python=3.10 -y
fi
conda activate "$ENV_NAME"

echo ">>> installing isaacsim 4.5 (~15-20GB, slow)"
pip install --upgrade pip

# 20GB of wheels over one link reliably corrupts at least one of them
# (BadZipFile / bad CRC). Purge the cache and retry rather than start over.
for attempt in 1 2 3 4; do
    echo ">>> pip attempt $attempt"
    if pip install "isaacsim[all,extscache]==4.5.0" --extra-index-url https://pypi.nvidia.com; then
        break
    fi
    echo ">>> attempt $attempt failed, purging cache"
    pip cache purge || true
    [ "$attempt" = 4 ] && { echo ">>> giving up"; exit 1; }
done

pip install imageio imageio-ffmpeg   # no ffmpeg binary on this host
pip install requests                 # several kit extensions import it and die without it

echo ">>> done: $(python -c 'import isaacsim; print(isaacsim.__version__)' 2>/dev/null || echo isaacsim)"

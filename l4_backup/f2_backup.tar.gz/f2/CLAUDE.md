# H1 pick-and-carry in the ASTRA SWEETS scan

Isaac Sim 4.5 demo: a Unitree H1 walks across a scanned candy-factory feed-station
area, grips a cube off a table, and carries it away.

## Work happens on workstation-1, not this machine

This PC has ~3.4 GB RAM free; Isaac Sim needs 10-16 GB to open a stage. Everything
runs on `ssi@workstation-1.local` (62 GB RAM, RTX A2000 12 GB, idle).

```bash
./sync.sh push          # code + assets up to ssi@workstation-1.local:~/f2
./sync.sh pull          # out/ (renders, logs) back down
./sync.sh watch         # push on every local change
ssh ssi@workstation-1.local 'cd ~/f2 && ~/miniforge3/envs/h1sim/bin/python h1_pick_demo.py --stage demo'
```

Git lives here and is the source of truth; the workstation is a plain rsync mirror
with no repo. Binary assets (`*.usdc *.stl *.exr *.mp4 *.png`) are git-lfs tracked.

The workstation is **headless** — no `DISPLAY`, no viewer. Everything is rendered
offscreen through a `Camera` prim and written to `out/`.

## Run it in stages

Each stage is independently checkable; don't jump to `demo` when something breaks.

| Stage | What it does |
|---|---|
| `--stage scene` | Room + table + cube only. Writes two stills. Use to check placement. |
| `--stage arm` | H1 parked at the table; reach, grip, lift. No walking. Use to tune the grasp. |
| `--stage demo` | The whole sequence → `out/demo.mp4`, with self-check assertions. |

`arm_ik.py` runs standalone with no Isaac Sim at all — `python arm_ik.py` executes
its self-check (FK against the USD, 200 IK round-trips). Run it after touching the
chain data.

## Things that will bite you

**The scan is authored 50 m from the origin.** `OFFICE_SHIFT` translates it so the
room's min corner is at `(0,0,0)` with the floor at `z=0`. Every coordinate in the
script is in that room frame; the room is 11.08 × 7.97 × 3.41 m. The scan is already
in metres (`metersPerUnit = 1.0`, Z-up) — do not rescale it.

**The scan contains no robot, no table, and no cube** — it is 270 static meshes with
no physics schemas whatsoever. We author the table and cube, and H1 comes from the
Nucleus asset server. Its own `SphereLight` and `Camera` sit at the CAD origin,
outside the room, so both are useless; we add a dome light and our own camera.

**H1 has no hands.** Each arm ends at `right_elbow_link`, a forearm running +X for
0.27 m. `add_gripper()` bolts two prismatic fingers onto it, mirroring how `h1.usd`
structures links (bodies as siblings under the articulation root, joint under its
parent link) so PhysX folds them into the articulation.

**Adding those fingers takes the articulation from 19 to 21 DoF, and PhysX RENUMBERS
EVERYTHING.** This cost hours, so read it twice. The fingers do not get appended at
indices 19–20; the whole articulation is reordered:

| joint | without gripper | with gripper |
|---|---|---|
| `torso` | 2 | **0** |
| `left_hip_yaw` | 0 | **3** |
| `left_elbow` | 17 | **13** |
| `left_ankle` | 15 | **19** |

So "dof_names minus the finger joints" is **not** the order the policy was trained on
and cannot be derived at runtime. `POLICY_JOINTS` in `h1_pick_demo.py` pins the
original order explicitly; `loco_idx` maps it onto whatever indices the articulation
currently uses. Get this wrong and the policy reads hips as torso, commands legs onto
the wrong joints, and the robot falls inside half a second — while the fingers sit
there looking innocent, which is exactly what makes it so slow to find. If you touch
the gripper, check the `[dofs]`/`[loco]` lines the script prints.

Related: `get_robot_joint_properties()` builds its gain arrays by pattern-matching
joint names, and the finger joints match nothing, so it silently returns 19-long
arrays for a 21-DoF articulation. Pass it `POLICY_JOINTS` and apply with
`joint_indices=`.

**Resolve DoF indices by name, never hardcode index numbers.** Isaac orders DoFs
breadth-first, so H1's joints come out interleaved (both hips, then torso, then both
shoulders, …), not grouped per limb — and as above, that order is not stable.

**The arm is 4-DoF, so only tool position is solvable** — orientation is whatever the
arm gives you, and there is no wrist to fix it. The gripper mount and `ARM_*` poses
are tuning knobs, not derived values. Single-seed IK has local minima against the
joint limits; use `arm_ik.reachable()` (8 seeds), not `arm_ik.ik()`.

**A 20 GB pip install corrupts wheels.** `setup_remote.sh` retries with a cache purge;
a `BadZipFile` / bad CRC is a flaky download, not a broken config.

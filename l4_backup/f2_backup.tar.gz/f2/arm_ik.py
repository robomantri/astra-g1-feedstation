#!/usr/bin/env python3
"""Forward/inverse kinematics for the H1 right arm, in torso_link frame.

Pure numpy so it can be developed and checked without Isaac Sim running.
Chain data was read straight out of Isaac's h1.usd joint definitions:
USD joint semantics are  T_parent_child = Translate(localPos0) @ Rot(localRot0) @ Rot(axis, q)
(localPos1/localRot1 are identity throughout this chain).

The arm is 4-DoF, so only tool *position* is solvable; orientation is whatever
the arm gives you. That is why the gripper is mounted to straddle the cube in
the pose the arm naturally reaches with -- see GRIP_* in h1_pick_demo.py.
"""
import numpy as np

# (localPos0, localRot0 as wxyz, rotation axis) for shoulder pitch/roll/yaw then elbow
CHAIN = [
    ((0.0055, -0.15535, 0.42999), (0.97629625, -0.21643849, 0.0, 0.0), "Y"),
    ((-0.0055, -0.0565, -0.0165), (0.97629625, 0.21643849, 0.0, 0.0), "X"),
    ((0.0, 0.0, -0.1343), (1.0, 0.0, 0.0, 0.0), "Z"),
    ((0.0185, 0.0, -0.198), (1.0, 0.0, 0.0, 0.0), "Y"),
]
JOINTS = [
    "right_shoulder_pitch_joint",
    "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint",
    "right_elbow_joint",
]
LIMITS = np.deg2rad([(-164.44, 164.44), (-178.19, 19.48), (-254.97, 74.48), (-71.62, 149.54)])


def _axis_rot(axis, q):
    c, s = np.cos(q), np.sin(q)
    if axis == "X":
        return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if axis == "Y":
        return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def _quat_rot(q):
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def fk(q, tool=(0.0, 0.0, 0.0)):
    """Tool pose in torso_link frame. Returns (position, rotation_matrix)."""
    p = np.zeros(3)
    R = np.eye(3)
    for (t, rq, axis), qi in zip(CHAIN, q):
        p = p + R @ np.asarray(t, float)
        R = R @ _quat_rot(rq) @ _axis_rot(axis, qi)
    return p + R @ np.asarray(tool, float), R


def _jacobian(q, tool, eps=1e-6):
    p0, _ = fk(q, tool)
    J = np.empty((3, len(q)))
    for i in range(len(q)):
        dq = np.array(q, float)
        dq[i] += eps
        J[:, i] = (fk(dq, tool)[0] - p0) / eps
    return J


def ik(target, q0, tool=(0.0, 0.0, 0.0), iters=300, damping=0.02, tol=1e-4):
    """Damped least-squares position IK with joint limits. Returns (q, error).

    Single-seed and therefore not reliable on its own -- a 4-DoF arm against
    joint limits has local minima. Use reachable() for anything load-bearing.
    """
    q = np.clip(np.array(q0, float), LIMITS[:, 0], LIMITS[:, 1])
    target = np.asarray(target, float)
    for _ in range(iters):
        p, _ = fk(q, tool)
        err = target - p
        if np.linalg.norm(err) < tol:
            break
        J = _jacobian(q, tool)
        # damped pseudo-inverse: stays stable at the singular fully-extended pose
        dq = J.T @ np.linalg.solve(J @ J.T + damping**2 * np.eye(3), err)
        q = np.clip(q + dq, LIMITS[:, 0], LIMITS[:, 1])
    return q, float(np.linalg.norm(target - fk(q, tool)[0]))


# Eight spread-out starts; measured over 300 random reachable targets this drives
# the worst residual to the solver tolerance, where four seeds left ~0.7% at >1mm.
SEEDS = (
    (0.0, 0.0, 0.0, 0.0), (0.3, -0.2, 0.0, 0.5), (1.0, -0.5, 0.0, 1.2), (-0.5, -0.9, 0.3, 0.8),
    (0.8, -1.5, -0.5, 1.0), (-1.2, -0.3, 0.8, 0.4), (1.5, -2.0, 0.5, 1.4), (0.0, -1.0, -1.0, 0.9),
)


def reachable(target, tool=(0.0, 0.0, 0.0), tol=0.02, prefer=None):
    """Multi-seed IK. Returns (ok, q, err).

    The arm is 4-DoF against 3 position constraints, so solutions come in a
    one-parameter family. `prefer` picks the one closest to a reference pose
    instead of whichever seed happened to converge first -- on a robot balancing
    on two feet, the solution that swings the arm least is the one that does not
    shove the centre of mass sideways and make it step.
    """
    sols = []
    fallback = (None, np.inf)
    for seed in SEEDS:
        q, e = ik(target, seed, tool)
        if e < fallback[1]:
            fallback = (q, e)
        if e <= tol:
            sols.append((q, e))
        if e < 1e-4 and prefer is None:
            break
    if not sols:
        return False, fallback[0], fallback[1]
    if prefer is None:
        q, e = min(sols, key=lambda s: s[1])
        return True, q, e
    # among solutions, favour the least arm travel -- but only from the ones that
    # actually hit the target, or "closest to home" quietly becomes "2 cm off"
    tight = [s for s in sols if s[1] <= 5e-3] or sols
    ref = np.asarray(prefer, float)
    q, e = min(tight, key=lambda s: float(np.max(np.abs(s[0] - ref))))
    return True, q, e


def demo():
    # 1. chain math matches what USD computes for right_elbow_link at zero pose
    p, _ = fk(np.zeros(4))
    assert np.allclose(p, [0.0185, -0.21353, 0.10661], atol=1e-4), p

    # 2. IK round-trips on poses the arm demonstrably has
    rng = np.random.default_rng(0)
    worst = 0.0
    for _ in range(200):
        q_true = rng.uniform(LIMITS[:, 0] * 0.6, LIMITS[:, 1] * 0.6)
        tgt, _ = fk(q_true, TOOL_TEST)
        ok, q, err = reachable(tgt, TOOL_TEST)
        worst = max(worst, err)
        assert ok, f"failed to reach {tgt}, residual {err:.4f}"
        assert np.all(q >= LIMITS[:, 0] - 1e-9) and np.all(q <= LIMITS[:, 1] + 1e-9), q
    assert worst < 1e-3, f"worst IK residual {worst:.5f}"

    # 3. something far outside the arm's reach must be reported unreachable
    ok, _, err = reachable([2.0, -2.0, 2.0], TOOL_TEST)
    assert not ok and err > 0.5, (ok, err)

    print(f"arm_ik ok - zero-pose FK matches USD, worst IK residual {worst:.2e} m")


TOOL_TEST = (0.33, 0.0, 0.0)  # roughly the gripper centre on the forearm

if __name__ == "__main__":
    demo()

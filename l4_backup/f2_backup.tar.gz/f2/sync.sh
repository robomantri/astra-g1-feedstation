#!/usr/bin/env bash
# Workspace sync with the GPU box. Code goes up, renders come down.
set -euo pipefail

REMOTE="ssi@workstation-1.local"
RDIR="~/f2"
LDIR="$(cd "$(dirname "$0")" && pwd)"

push() {
    rsync -az --delete \
        --exclude '.git' --exclude '__pycache__' --exclude 'out' \
        --exclude '*.zip' \
        "$LDIR/" "$REMOTE:$RDIR/"
}

case "${1:-push}" in
    push) push; echo "pushed -> $REMOTE:$RDIR" ;;
    pull) mkdir -p "$LDIR/out"
          rsync -az "$REMOTE:$RDIR/out/" "$LDIR/out/"
          echo "pulled <- $REMOTE:$RDIR/out" ;;
    watch) push; echo "watching $LDIR"
           while inotifywait -qq -r -e modify,create,delete,move \
                 --exclude '(\.git|__pycache__|out)' "$LDIR"; do
               push && echo "synced $(date +%T)"
           done ;;
    *) echo "usage: $0 {push|pull|watch}" >&2; exit 1 ;;
esac

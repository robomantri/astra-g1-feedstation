#!/usr/bin/env python3
"""Unitree H1 walks across the ASTRA SWEETS scan, grips a cube off a table, carries it away.

  python h1_pick_demo.py --stage scene   # room + table + cube, two stills. Check placement.
  python h1_pick_demo.py --stage walk    # office + stock locomotion policy, no gripper.
  python h1_pick_demo.py --stage arm     # H1 parked at the table, reach + grip only.
  python h1_pick_demo.py --stage demo    # the whole thing -> out/demo.mp4

Headless only; workstation-1 has no display.
"""
import argparse
import inspect
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- tunables --
# Room frame: scan's min corner at the origin, WALKABLE FLOOR at z=0, metres.
# The scan sits ~50 m from the origin, and its floor slab is 0.277 m thick -- the
# z term lands the slab's *top* on zero, not its underside, or everything placed
# in this file would sit 28 cm inside the floor.
OFFICE_USD = os.path.join(HERE, "assets", "office.usdc")
FLOOR_THICKNESS = 0.276737
OFFICE_SHIFT = (51.5357, -30.5250, 2.70648 - FLOOR_THICKNESS)
ROOM = (11.078, 7.974)   # room extent in the shifted frame, from the scan bbox

# Table position was picked by scanning the room for the spot with the most
# clearance to any scan geometry between 3 cm and 2 m above the floor. This one
# has 1.47 m; the obvious-looking mid-room spot had 0.74 m and visibly wedged the
# table between a kerb and a post.
# Bench and cube placement are NOT cosmetic -- they are set by the arm's measured
# reach envelope. H1's 4-DoF arm tops out around 0.50 m FORWARD of the torso, so a
# head-on grasp is unsolvable and the robot reaches at full stretch and topples.
# Standing head-on also puts its toes ~4 cm from the bench, and it kicks the bench
# over as it sways (this happens even with the arm frozen).
# Sideways is the arm's happy place: 0.22 m forward, 0.30 m to the RIGHT, is ~9 deg
# of joint travel from ARM_HOME. So the robot parks ALONGSIDE the bench, feet
# parallel to it, and reaches out sideways. Re-check arm_ik.reachable() if you move
# any of these.
TABLE_XY, TABLE_TOP, TABLE_HALF = (8.55, 1.40), 0.80, (0.45, 0.30)
CUBE_XY, CUBE_SIZE, CUBE_MASS = (8.37, 1.62), 0.08, 0.25

# The robot keeps to y~2.0 the whole way -- the one lane measured clear across the
# full width of the room, and the lane --stage walk already traversed upright.
# It stops beside the table and turns to face it rather than driving at it.
# The demo starts 1.2 m out, not 5.4 m. With the gripper attached the robot walks
# about 1.5 m before going down -- ruled out as gains, finger drives, self-collision
# and action batching, so what remains is the two extra articulation links, which no
# constant fixes. --no-gripper covers the same 5.4 m upright, so the long walk is
# real and lives in --stage walk; the demo shows the last approach plus the pick.
H1_START = (7.20, 1.95)
# Walk up the lane, then TURN AND FACE THE TABLE to pick -- the robot squares up to
# the bench rather than sidling along it. The note above says a head-on grasp is
# unsolvable; that was measured approaching along +x from 0.40 m out, where the cube
# sits at the very edge of the arm's forward envelope. Facing the bench across the
# lane instead (turn right, cube almost straight ahead at 0.38 m) is solvable, and
# arm_ik.reachable() puts pregrasp/grasp/lift all at 0.0 cm residual from here.
# Clearance to the bench footprint is 0.30 m, exactly what the old sideways stance
# had, so this is no closer to kicking it over. It does cost arm travel: 58.8 deg
# from ARM_HOME versus 12.0 deg sideways -- affordable only because the base is
# pinned through the pick. Re-run arm_ik.reachable() if you move any of this.
# Square to the bench, 10 cm in from the walk lane. The arm's reach along the
# cube's bearing tops out at ~0.36 m (measured with arm_ik.reachable); from
# y=2.00 the cube sits at 0.391 m -- 3 cm outside the envelope, so IK returns its
# nearest point and the hand stalls 32 cm away with the jaws still open.
# y=1.90 brings all three grasp targets inside the envelope, but only just: the
# hand still lands ~5 cm short of the cube in y, because servo_arm's bias clip
# (+/-0.08 m) cannot cancel the whole droop at full stretch. The grip centre then
# sits outside SURF_THRESHOLD (0.05 m) so the attach never latches, and the
# closing jaws shove the cube away instead of caging it. y=1.85 was tried to buy
# that 5 cm back: every grasp target still solves to <1 mm there, but the arm's
# PATH from ARM_HOME up to the pregrasp then sweeps through the cube and launches
# it off the bench at t=0.6 s. Reachable endpoints do not imply a clear path, and
# the window between 'cannot reach' and 'hits it on the way in' is narrower than
# the droop error -- so fix the placement or the capture radius, not the stance.
STAND_XY = (8.40, 1.90)
WORK_YAW = np.radians(-94.5)     # face -y, i.e. straight at the table
APPROACH_TIMEOUT = 12.0          # s; stop circling and let the pin finish the job
APPROACH_STOP = 0.35             # m; stop short and let the pin place the base
FACE_CREEP = 0.06                # m/s kept on during the turn; a planted-feet pivot
                                 # topples the policy, a slow walking turn does not
FACE_TIMEOUT = 8.0               # s; give up squaring up rather than stall forever
# Carry it back the way it came -- but only as far as the robot can actually walk
# with the gripper fitted. 4.00 is 4.4 m from the bench; measured, H1 manages about
# 1.5 m before the two extra finger links tip the locomotion policy over, and it
# went down at t=36.6 s mid-carry with the cube already in hand. 1.1 m is inside
# that, so the carry is real walking rather than a scripted slide.
DROP_XY = (7.30, 2.05)
WALK_START, WALK_GOAL = (3.00, 2.00), (8.60, 2.00)

# Gripper: two fingers on prismatic joints straight onto the forearm, which runs
# +X from the elbow and ends at 0.27. No wrist on H1, so the fingers' closing
# direction is fixed by the arm pose -- they close along the forearm's Y.
GRIP_MOUNT_X = 0.255
# Jaw roll about the forearm axis. TRIED AND REJECTED at 13.7 deg (the measured jaw
# tilt at the grasp pose): the intent was face-parallel contact instead of pinching
# the cube's top edges, but it made the approach miss -- jaws closed to 0.030 on
# empty air and punted the cube 1.5 m. Left as a knob because edge contact is still
# the reason the grip only holds 2-3 s; it needs the grasp pose re-tuned alongside
# it, not a roll bolted onto the existing one.
GRIP_MOUNT_ROLL = 0.0
FINGER_LEN, FINGER_THK, FINGER_HT = 0.11, 0.016, 0.05
# Half-separation is measured between finger CENTRES, but the jaws grip with their
# inner faces, half a finger-thickness further in. Closing to CUBE_SIZE/2 therefore
# commands the faces ~8 mm INSIDE the cube on each side: the drive never reaches
# its target, keeps pushing, and squirts the cube out -- measured as a clean 0.22 m
# lift that slipped free two seconds later. Target the faces on the cube's surface
# with a couple of mm of interference for grip.
GRIP_OPEN = 0.070
# 6 mm of interference past the cube's face. Commanding the faces exactly ON the
# surface means the drive reaches its target and presses with ~0 N, so the cube just
# rests between the jaws and shakes loose on the lift.
# Measured, not derived. The jaws sit ~14 deg off horizontal so they pinch the
# cube's EDGES, not its flat faces, and reach equilibrium around a 0.114 m gap
# (half-separation 0.057) rather than the 0.096 the flat-face geometry predicts.
# Commanding far past that just grinds through and pops the cube out after a few
# seconds. Sit slightly inside the equilibrium for a steady squeeze.
GRIP_CLOSED = 0.0515
# --rail: cage, never squeeze. The cube's half-width is 0.040 and a finger is 0.016
# thick, so its inner face sits at half_gap - 0.008; anything under 0.048 puts the
# jaw inside the cube. Held kinematic through the swing the cube cannot push back,
# so the jaws just close through it and the overlap fires it away on release.
# 0.058 leaves a 10 mm gap per side -- the surface attach does the holding anyway.
RAIL_GRIP_CLOSED = 0.058
# Close the jaws at a finite speed. A step command with stiff drives is a ~40 N
# hammer blow that punts the cube out sideways before contact can settle; too soft
# a squeeze and it shakes loose on the lift. Ramp in, then hold.
GRIP_RATE = 0.05         # m/s
# Descend with the jaws WIDE. Caging to 0.11 m leaves only 8 mm either side of an
# 0.08 m cube, so any approach error clips its edge and drags it out of reach. The
# cage was worth it when the base was drifting; with the base pinned it just costs
# clearance.
GRIP_CAGE = GRIP_OPEN
# Squeeze force = KP * (commanded - actual), CAPPED at MAX_FORCE. Keep KP stiff so
# the jaws track their target briskly, but cap the force hard -- the cap, not the
# gain, is what decides whether the cube survives.
#
# Measured on arm_v29, the run that lifted 0.31 m and then dropped it:
#   t=6.0  fingA=[-0.0104, 0.0107] vs commanded -0.0185 -> 8.1 mm error -> 12.2 N. Held.
#   t=7.0  fingA=[-0.0184, 0.0186] -> 0.1 mm error -> 0.15 N. Jaws fully shut, cube gone.
#   armVmax=0.01 rad/s across that whole interval -- the ARM WAS NOT MOVING.
# So the cube was not shaken loose, and it did not slip: 12 N of squeeze extruded it,
# like a watermelon seed. The jaws sit ~14 deg off horizontal (a 4-DoF wristless arm
# cannot orient them) so they only ever touch the cube's EDGES, and edge contact under
# a force that large has nowhere to go but out.
#
# Raising friction or slowing the lift both push the wrong way -- friction is already
# 2.0/1.8, and the arm was stationary.
#
# KP and MAX_FORCE are NOT interchangeable knobs here, which cost a run to learn:
#   MAX_FORCE = the finger's authority to hold its commanded position
#   KP        = the squeeze it applies once the cube blocks it
# arm_v30 capped MAX_FORCE at 5 N and regressed badly: incidental contact during the
# descend knocked finger b to its 0.09 joint limit, and recovering 90 mm of error needs
# KP*0.09 = 135 N, so at a 5 N ceiling it stayed jammed there for the rest of the run.
# A stuck finger poisons grip_center() (the fingertip MIDPOINT moves ~45 mm), which
# feeds cart_bias, which drags the IK target onto a folded branch (elbow 134 deg vs
# 42 deg) -- descend then timed out and the shut jaws swatted the cube onto the floor.
#
# So: leave MAX_FORCE high enough to recover from a knock, and lower KP instead. At the
# measured 8.1 mm contact interference, KP=600 gives ~4.9 N of squeeze -- across two
# contacts at mu=1.8 that still holds ~17 N against a 2.45 N cube (7x margin) while
# being far too weak to extrude it, and 600*0.09 = 54 N of recovery authority remains.
# With no wrist the cube rotates as the arm lifts, and a rotated 0.08 m cube needs
# half-diagonal 0.0566 + half a finger thickness = 0.0646 m of gap -- more than
# GRIP_CLOSED's 0.0515. Measured: the jaws wedged open to exactly 0.0645 while the
# cube was airborne, then the attach tore loose. Dropping the force to 5 N so the
# jaws would yield instead was worse: they then sagged open under their own weight
# (gap 0.177 vs 0.140 commanded) and swept the cube off the bench during reach.
# The jaws need force to hold position; the fix has to be geometric, not softer.
GRIP_KP, GRIP_KD, GRIP_MAX_FORCE = 600.0, 50.0, 40.0
# While walking the fingers are dead weight that should not push back. Enough drive
# to stop them flapping, far too little to disturb a robot balancing on two feet.
GRIP_KP_WALK, GRIP_KD_WALK, GRIP_MAX_FORCE_WALK = 60.0, 15.0, 2.0
FINGER_MASS = 0.06
# The policy's own arm gains are tuned for a free-swinging arm, not for holding a
# commanded pose against gravity plus a gripper. Measured 8.5 deg of elbow droop at
# the grasp, which is ~4.5 cm of tool height -- exactly enough to close the jaws
# above the cube. We override these four joints anyway, so stiffen them.
# At 400/20 the arm sagged ~0.12 m below its commanded pose at full stretch --
# arm_ik.reachable() solves every one of those targets to 0.0000, so the shortfall
# was control, not geometry. The sag left the hand ~0.05 m short of the cube,
# which is outside SURF_THRESHOLD (0.05 m), so the attach never latched. Stiffened
# 3x; KD scaled by ~sqrt(3) to hold the damping ratio roughly constant.
# Two gain sets, because the arm has two jobs. Pinned at the bench it must hold a
# commanded pose against gravity: at 400 it sagged ~0.12 m and the hand landed 5 cm
# short of the cube. Free-standing it must NOT fight the locomotion policy: 1200
# while walking put enough reaction torque through the torso to topple the robot at
# t=2.6 s of --stage demo. So: soft on the move, stiff only once the base is pinned.
ARM_KP, ARM_KD = 400.0, 20.0                  # walking -- gentle on the balance
ARM_KP_GRASP, ARM_KD_GRASP = 1200.0, 35.0     # pinned at the bench -- hold the pose
TOOL = (GRIP_MOUNT_X + FINGER_LEN * 0.55, 0.0, 0.0)     # IK target point on the forearm

ARM_HOME = np.array([0.28, 0.0, 0.0, 0.52])   # policy's default right-arm pose
# ARM_CARRY as a hand-picked joint pose was a trap: [0.55,-0.25,0,1.45] puts the
# tool at torso (-0.29,-0.34,-0.12), i.e. DOWN and BEHIND the robot, so "lift"
# quietly pushed the cube into the bench. The lift is Cartesian now -- straight up
# from wherever the cube was grasped, which arm_ik confirms is reachable to +0.30 m.
# 0.25 was never completed: the attach released around 0.21 m every time. The arm
# has no wrist, so the further it lifts the more it rotates the payload -- shorten
# the lift and it finishes before that accumulates. 0.15 m still clears the bench.
LIFT_UP = 0.15
# Max joint-target speed for the arm. Snapping straight to an IK solution makes the
# position drives slam the arm across in one tick, and the reaction torque tips the
# robot over -- it is balancing on two feet, not bolted to a bench.
# Dropping this to 0.5 to gentle the lift backfired: the slower slew made the arm
# trace a longer, lower arc into the pregrasp -- it dipped to z=0.85, 0.19 m under
# its target, and swept the cube off the bench before the grasp. The rate governs
# the PATH, not just the speed, so the lift has to be made survivable at the
# attach instead (see SURF_TORQUE_LIMIT).
ARM_RATE = 1.2                                # rad/s; fast lifts shake the cube free
PREGRASP_UP = 0.20       # swing in this high so the jaws clear the cube

GRIP_JOINTS = ("right_gripper_a_joint", "right_gripper_b_joint")

# ------------------------------------------------------------ surface grip ---
# WHY THIS EXISTS. Three runs proved the friction grasp has no stable operating
# point on this robot, and the reason is structural, not a bad gain:
#   arm_v29  KP=1500 F=40  ->  12.2 N squeeze, cube EXTRUDED after a 0.31 m lift
#   arm_v30  KP=1500 F=5   ->  finger jammed at its joint limit, cube swatted off
#   arm_v31  KP=600  F=40  ->  ~0 N squeeze at the lift, cube slipped free
# H1's arm is 4-DoF with no wrist, so the jaws cannot be rotated flat against the
# cube -- they meet it at ~14 deg and only ever touch its EDGES. Edge contact has
# no squeeze window: too little and it slips, too much and it extrudes.
#
# isaacsim.robot.surface_gripper is NVIDIA's own answer to exactly this, and an
# Isaac Lab maintainer recommends it over friction grasping for grasp-like tasks
# (see RESEARCH.md). It spawns a D6 joint between the gripper body and whatever
# rigid body is within gripThreshold, so it does not care about jaw orientation.
#
# What stays real: gravity on the cube (disable_gravity=False -- the cube has
# weight the whole time), the arm's torques, every contact in the scene, and the
# walking either side of the pick. What is simulated away: the friction pinch
# itself. The attach is force-limited, not a weld -- exceed SURF_FORCE_LIMIT and
# it lets go, so a bad grasp still drops the cube.
# ponytail: attach-on-contact instead of a friction pinch; the real fix is a
# wristed arm (h1_with_hand.usd adds one roll DoF, still not enough) or a hand,
# which is an asset change, not a tuning job.
# The grip point must sit where the CUBE will be, and its threshold must be too
# short to touch our own jaws -- at translate=GRIP_MOUNT_X with threshold 0.10 it
# grabbed its own finger during the raise (surf=Y with nothing commanded, gap
# collapsing 0.140 -> 0.078), and a stuck finger poisons grip_center() -> cart_bias
# -> the descend IK, which then froze 0.32 m short of the cube.
# Fingers sit at +/-GRIP_OPEN with their inner faces half a thickness in, i.e. at
# 0.070 - 0.008 = 0.062 m laterally. Stay under that with margin.
SURF_TRANSLATE = TOOL[0]               # the tool point, i.e. between the fingertips
SURF_THRESHOLD = 0.05                  # < 0.062, so it can never catch a jaw
# --rail capture radius. This was cut to 0.08 after a wide radius let the attach
# snatch the cube during the walk-in, but that is now prevented properly -- the
# gripper is held OPEN until the 'close' phase asks for it, so the radius no longer
# has to do that job. It only has to cover where the hand actually ends up: the
# descend touches 0.063 m and then drifts back to 0.110 by the time close fires.
SURF_THRESHOLD_RAIL = 0.15
# 50 N sounds generous against a 2.45 N cube, but paired with SURF_KP=1.0e5 it is
# reached after 0.5 mm of deflection -- a tripwire, not a grip, and it let go a
# second into every lift. Softening SURF_KP instead was tried and regressed the
# APPROACH (the cube got swept before the grasp), so the headroom is bought here:
# 200 N is 2 mm of travel, still finite and still breakable.
SURF_FORCE_LIMIT = 200.0               # N -- 80x the cube's 2.45 N weight, finite
# 5.0 flung the cube; 25.0 lifts it 0.21 m and is the best measured. Raising it to
# 100.0 made things WORSE -- the attach let go earlier -- so torque is not simply
# the binding limit here, and cranking it further is not the fix. Left at the value
# that actually performed best.
SURF_TORQUE_LIMIT = 25.0               # N.m
SURF_KP, SURF_KD = 1.0e5, 1.0e4        # stiff enough that the cube does not sag

# THE joint order the pretrained policy expects: H1's articulation order BEFORE the
# fingers exist. Adding two DoF does not append them -- PhysX renumbers the whole
# articulation (torso 2->0, left_hip_yaw 0->3, left_elbow 17->13, left_ankle 15->19),
# so "dof_names minus the fingers" is NOT the training order and cannot be derived
# at runtime. Feed the policy the wrong order and it reads hips as torso, commands
# legs onto the wrong joints, and the robot falls over inside half a second.
POLICY_JOINTS = (
    "left_hip_yaw_joint", "right_hip_yaw_joint", "torso_joint",
    "left_hip_roll_joint", "right_hip_roll_joint",
    "left_shoulder_pitch_joint", "right_shoulder_pitch_joint",
    "left_hip_pitch_joint", "right_hip_pitch_joint",
    "left_shoulder_roll_joint", "right_shoulder_roll_joint",
    "left_knee_joint", "right_knee_joint",
    "left_shoulder_yaw_joint", "right_shoulder_yaw_joint",
    "left_ankle_joint", "right_ankle_joint",
    "left_elbow_joint", "right_elbow_joint",
)
ARM_JOINTS = (
    "right_shoulder_pitch_joint", "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint", "right_elbow_joint",
)

PHYS_DT = 1.0 / 200.0
CAPTURE_EVERY = 8        # -> 25 fps video
IK_EVERY = 5             # re-solve the arm at 40 Hz while closing in

# Camera lives in the far corner of the room looking back down the work aisle,
# which frames the table and the whole walk path.
CAM_EYE, CAM_LOOK = (0.90, 6.50, 2.95), (6.20, 1.40, 0.85)

# --------------------------------------------------------------- boot kit ---
parser = argparse.ArgumentParser()
parser.add_argument("--stage", choices=("scene", "walk", "arm", "demo"), default="demo")
parser.add_argument("--out", default=os.path.join(HERE, "out"))
parser.add_argument("--seconds", type=float, default=42.0)
parser.add_argument("--res", type=int, nargs=2, default=(1280, 720))
parser.add_argument("--freeze-arm", action="store_true",
                    help="hold the arm at ARM_HOME; isolates balance from arm motion")
parser.add_argument("--no-gripper", action="store_true",
                    help="skip the fingers entirely; isolates balance from the gripper")
parser.add_argument("--name", default=None,
                    help="basename for the video (default: the stage name)")
parser.add_argument("--self-collide", action="store_true",
                    help="leave self-collisions ON (default disables them so the "
                         "fingers can occupy the hip at ARM_HOME)")
parser.add_argument("--rail", action="store_true",
                    help="demo mode: carry the base along a scripted path for the "
                         "whole run and drive the phases off the clock")
parser.add_argument("--glue", action="store_true",
                    help="demo mode: make the surface attach unbreakable once it "
                         "latches, so the carry is guaranteed on camera")
args = parser.parse_args()

if args.rail:
    SURF_THRESHOLD = SURF_THRESHOLD_RAIL
if args.glue:
    # DEMO ONLY -- this is not a physics result. The attach normally breaks on a
    # force/torque threshold, which is the point of a surface gripper; here those
    # thresholds are raised past anything the arm can generate, so a latched cube
    # rides along as if welded. The grasp up to the latch is still real: the arm
    # reaches, the jaws close, and the attach only forms on contact within
    # SURF_THRESHOLD. What is faked is retention, nothing before it.
    SURF_FORCE_LIMIT = 1.0e6
    SURF_TORQUE_LIMIT = 1.0e6

from isaacsim import SimulationApp  # noqa: E402

sim_app = SimulationApp({"headless": True})

import omni.usd  # noqa: E402
from isaacsim.core.api import World  # noqa: E402
from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid, GroundPlane  # noqa: E402
from isaacsim.core.api.materials import PhysicsMaterial  # noqa: E402
from isaacsim.core.prims import SingleXFormPrim  # noqa: E402
from isaacsim.core.utils.stage import add_reference_to_stage  # noqa: E402
from isaacsim.core.utils.types import ArticulationAction  # noqa: E402
from isaacsim.robot.policy.examples.robots.h1 import H1FlatTerrainPolicy  # noqa: E402
# SurfaceGripper is imported at its point of use, not here: Isaac Sim 6.0 dropped
# the plain SurfaceGripper name (it has SurfaceGripperComponent/Interface/Manager),
# and a module-level import takes down --stage walk too, which never grips.
from isaacsim.robot.policy.examples.controllers.config_loader import (  # noqa: E402
    get_robot_joint_properties,
)
from isaacsim.sensors.camera import Camera  # noqa: E402
from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade  # noqa: E402

import arm_ik  # noqa: E402


# ------------------------------------------------------------------ utils ---
def quat_look_at(eye, target):
    """USD cameras look down their local -Z with +Y up. Returns wxyz."""
    eye, target = np.asarray(eye, float), np.asarray(target, float)
    fwd = eye - target                      # camera +Z points back at the eye
    fwd /= np.linalg.norm(fwd)
    right = np.cross([0.0, 0.0, 1.0], fwd)
    n = np.linalg.norm(right)
    right = np.array([1.0, 0.0, 0.0]) if n < 1e-6 else right / n
    up = np.cross(fwd, right)
    R = np.column_stack([right, up, fwd])
    t = np.trace(R)
    if t > 0:
        s = 0.5 / np.sqrt(t + 1.0)
        q = np.array([0.25 / s, (R[2, 1] - R[1, 2]) * s, (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s])
    else:
        i = int(np.argmax(np.diag(R)))
        j, k = (i + 1) % 3, (i + 2) % 3
        s = 2.0 * np.sqrt(1.0 + R[i, i] - R[j, j] - R[k, k])
        q = np.zeros(4)
        q[0] = (R[k, j] - R[j, k]) / s
        q[i + 1] = 0.25 * s
        q[j + 1] = (R[j, i] + R[i, j]) / s
        q[k + 1] = (R[k, i] + R[i, k]) / s
    return q / np.linalg.norm(q)


def R_to_quat(R):
    """Rotation matrix -> wxyz quaternion."""
    t = np.trace(R)
    if t > 0:
        s = 0.5 / np.sqrt(t + 1.0)
        return np.array([0.25 / s, (R[2, 1] - R[1, 2]) * s,
                         (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s])
    i = int(np.argmax(np.diag(R)))
    j, k = (i + 1) % 3, (i + 2) % 3
    s = 2.0 * np.sqrt(1.0 + R[i, i] - R[j, j] - R[k, k])
    q = np.zeros(4)
    q[0] = (R[k, j] - R[j, k]) / s
    q[i + 1] = 0.25 * s
    q[j + 1] = (R[j, i] + R[i, j]) / s
    q[k + 1] = (R[k, i] + R[i, k]) / s
    return q / np.linalg.norm(q)


def quat_to_R(q):
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def yaw_of(q):
    R = quat_to_R(q)
    return float(np.arctan2(R[1, 0], R[0, 0]))


def wrap(a):
    return (a + np.pi) % (2.0 * np.pi) - np.pi


# ------------------------------------------------------------------ scene ---
def add_office(stage):
    """Reference the scan and make every mesh a static triangle-mesh collider."""
    add_reference_to_stage(usd_path=OFFICE_USD, prim_path="/World/Office")
    SingleXFormPrim("/World/Office").set_world_pose(position=np.array(OFFICE_SHIFT))
    n = 0
    for prim in Usd.PrimRange(stage.GetPrimAtPath("/World/Office")):
        if prim.IsA(UsdGeom.Mesh):
            UsdPhysics.CollisionAPI.Apply(prim)
            # exact triangles: legal here because the scan never moves
            UsdPhysics.MeshCollisionAPI.Apply(prim).CreateApproximationAttr("none")
            n += 1
    print(f"[scene] office: {n} static colliders, floor at z=0", flush=True)


def add_gripper(stage, grip_mat):
    """Two prismatic fingers bolted to the right forearm.

    Authored to mirror h1.usd exactly: link prims are siblings under the
    articulation root, and the joint lives under its parent link. That is what
    makes PhysX fold them into H1's articulation instead of leaving them loose.
    """
    elbow = "/World/H1/right_elbow_link"
    # Place the fingers on the forearm as it sits in ARM_HOME -- the stance the
    # robot actually starts in. Authoring them at the USD zero pose instead leaves
    # them a good 20 cm off the forearm, and on the first physics tick the
    # prismatic joints yank them into place hard enough to knock the robot over.
    elbow_p, elbow_R = arm_ik.fk(ARM_HOME)
    c, sr = np.cos(GRIP_MOUNT_ROLL), np.sin(GRIP_MOUNT_ROLL)
    roll = np.array([[1, 0, 0], [0, c, -sr], [0, sr, c]])
    elbow_quat = R_to_quat(elbow_R @ roll)
    for name, sign in zip(GRIP_JOINTS, (+1.0, -1.0)):
        body = f"/World/H1/{name.replace('_joint', '')}"
        xf = UsdGeom.Xform.Define(stage, body)
        offset = np.array([GRIP_MOUNT_X, 0.0, 0.0]) + roll @ np.array([0.0, sign * GRIP_OPEN, 0.0])
        pos = elbow_p + elbow_R @ offset
        xf.AddTranslateOp().Set(Gf.Vec3d(*[float(v) for v in pos]))
        xf.AddOrientOp().Set(Gf.Quatf(float(elbow_quat[0]), Gf.Vec3f(
            float(elbow_quat[1]), float(elbow_quat[2]), float(elbow_quat[3]))))
        prim = xf.GetPrim()
        UsdPhysics.RigidBodyAPI.Apply(prim)
        UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(FINGER_MASS)

        geom = UsdGeom.Cube.Define(stage, body + "/geom")
        geom.GetSizeAttr().Set(2.0)                       # unit cube spans -1..1
        geom.AddTranslateOp().Set(Gf.Vec3d(FINGER_LEN / 2, 0.0, 0.0))
        geom.AddScaleOp().Set(Gf.Vec3f(FINGER_LEN / 2, FINGER_THK / 2, FINGER_HT / 2))
        UsdPhysics.CollisionAPI.Apply(geom.GetPrim())
        UsdPhysics.MeshCollisionAPI.Apply(geom.GetPrim()).CreateApproximationAttr("convexHull")
        # PhysicsMaterial has no .apply(); binding to a raw prim goes through
        # MaterialBindingAPI with the "physics" purpose. The friction here is what
        # stops the cube squirting out from between the fingers.
        UsdShade.MaterialBindingAPI(geom.GetPrim()).Bind(
            grip_mat.material, UsdShade.Tokens.weakerThanDescendants, "physics")

        joint = UsdPhysics.PrismaticJoint.Define(stage, f"{elbow}/{name}")
        joint.CreateBody0Rel().SetTargets([elbow])
        joint.CreateBody1Rel().SetTargets([body])
        joint.CreateAxisAttr("Y")
        joint.CreateLocalPos0Attr(Gf.Vec3f(*[float(v) for v in offset]))
        joint.CreateLocalRot0Attr(Gf.Quatf(float(np.cos(GRIP_MOUNT_ROLL / 2)),
                                           Gf.Vec3f(float(np.sin(GRIP_MOUNT_ROLL / 2)), 0.0, 0.0)))
        joint.CreateLocalPos1Attr(Gf.Vec3f(0.0, 0.0, 0.0))
        joint.CreateLowerLimitAttr(-0.09)
        joint.CreateUpperLimitAttr(0.09)
        # Holding a 0.35 kg cube at mu=1.2 needs about 1.4 N of squeeze. Stiff
        # drives here (4000 N/m) put hundreds of newtons through a 0.12 kg finger
        # hanging off the forearm and shove the whole robot over -- with the
        # gripper removed the same stance is rock steady for 14 s.
        drive = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), "linear")
        drive.CreateTypeAttr("force")
        drive.CreateMaxForceAttr(GRIP_MAX_FORCE)
        drive.CreateStiffnessAttr(GRIP_KP)
        drive.CreateDampingAttr(GRIP_KD)
        drive.CreateTargetPositionAttr(0.0)
    print("[scene] gripper: 2 prismatic fingers on right_elbow_link")


def build(world):
    stage = omni.usd.get_context().get_stage()
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

    grip_mat = PhysicsMaterial(
        "/World/Looks/grip", static_friction=2.0, dynamic_friction=1.8, restitution=0.0)

    # Backstop only, well below the scan's slab, and hidden: the robot walks on
    # the scanned floor. A visible plane level with it would z-fight.
    ground = GroundPlane("/World/ground", z_position=-1.0)
    UsdGeom.Imageable(ground.prim).MakeInvisible()
    # the scan's own light and camera sit outside the room at the CAD origin, so
    # they are useless -- light the place ourselves
    sky = stage.DefinePrim("/World/sky", "DomeLight")
    sky.CreateAttribute("inputs:intensity", Sdf.ValueTypeNames.Float).Set(500.0)

    add_office(stage)

    table = FixedCuboid(
        "/World/table", position=np.array([*TABLE_XY, TABLE_TOP / 2]),
        scale=np.array([TABLE_HALF[0] * 2, TABLE_HALF[1] * 2, TABLE_TOP]),
        color=np.array([0.45, 0.33, 0.22]))
    table.apply_physics_material(grip_mat)

    cube = world.scene.add(DynamicCuboid(
        "/World/cube", name="cube",
        position=np.array([*CUBE_XY, TABLE_TOP + CUBE_SIZE / 2 + 0.001]),
        scale=np.array([CUBE_SIZE] * 3), mass=CUBE_MASS,
        color=np.array([0.9, 0.25, 0.15])))
    cube.apply_physics_material(grip_mat)
    return cube, grip_mat


# -------------------------------------------------------------- 6.0 shim ---
class _Art45:
    """Isaac Sim 4.5's articulation API over 6.0's warp-backed Articulation.

    6.0 replaced isaacsim.core.prims.Articulation (numpy, one prim, joint-named
    methods) with isaacsim.core.experimental.prims.Articulation (warp arrays,
    batched over N prims, DOF-named methods). Everything below is written in the
    4.5 spelling, so wrap the object once here instead of rewriting 21 call
    sites -- which also keeps this script running unchanged on a real 4.5
    install, where the wrapper is never applied.

    Attributes not named here pass straight through, so the stock policy's own
    6.0-native calls against the same object keep working.
    """

    def __init__(self, art):
        object.__setattr__(self, "_a", art)

    def __getattr__(self, name):            # reached only when lookup misses
        return getattr(object.__getattribute__(self, "_a"), name)

    def __setattr__(self, name, value):
        setattr(object.__getattribute__(self, "_a"), name, value)

    @staticmethod
    def _row(a):
        """(1, k) warp or numpy array -> plain 1-D numpy row."""
        return np.asarray(a.numpy() if hasattr(a, "numpy") else a)[0]

    @staticmethod
    def _batch(v, k):
        """1-D value -> the (1, k) batch 6.0 expects for a single prim."""
        return np.asarray(v, dtype=np.float32).reshape(1, k)

    def get_joint_positions(self):
        return self._row(self._a.get_dof_positions())

    def get_joint_velocities(self):
        return self._row(self._a.get_dof_velocities())

    def set_joint_positions(self, values, joint_indices=None):
        self._a.set_dof_positions(self._batch(values, -1), dof_indices=joint_indices)

    def set_joint_velocities(self, values, joint_indices=None):
        self._a.set_dof_velocities(self._batch(values, -1), dof_indices=joint_indices)

    def get_world_pose(self):
        pos, quat = self._a.get_world_poses()
        return self._row(pos), self._row(quat)

    def set_world_pose(self, position=None, orientation=None):
        self._a.set_world_poses(
            None if position is None else self._batch(position, 3),
            None if orientation is None else self._batch(orientation, 4))

    def get_linear_velocity(self):
        return self._row(self._a.get_velocities()[0])

    def get_angular_velocity(self):
        return self._row(self._a.get_velocities()[1])

    def set_linear_velocity(self, value):
        self._a.set_velocities(linear_velocities=self._batch(value, 3))

    def set_angular_velocity(self, value):
        self._a.set_velocities(angular_velocities=self._batch(value, 3))

    def set_enabled_self_collisions(self, enabled):
        self._a.set_enabled_self_collisions(bool(enabled))

    def apply_action(self, action):
        # 4.5 drove position targets through an ArticulationAction; 6.0 sets
        # them directly. Only the joint_positions form is used in this script.
        self._a.set_dof_position_targets(
            self._batch(action.joint_positions, -1),
            dof_indices=getattr(action, "joint_indices", None))


def _policy_command(h1, cmd):
    """Command vector in whatever type the installed policy's observation wants.

    6.0's stock H1 policy builds its observation as a torch tensor on the robot's
    device and assigns the command straight into it, so a numpy command raises
    "can't assign a numpy.ndarray to a torch.FloatTensor". 4.5's observation was
    numpy throughout and takes cmd unchanged.
    """
    if isinstance(h1.robot, _Art45):
        import torch
        return torch.as_tensor(cmd, dtype=torch.float32,
                               device=torch.device(str(h1.robot._device)))
    return cmd


# ------------------------------------------------------------------ robot ---
class H1WithGripper(H1FlatTerrainPolicy):
    """H1 whose articulation gained two finger DoFs.

    The pretrained policy only knows the original 19 joints, so every read and
    write it does is confined to those indices. Without this the gains array
    comes back short of the DoF count and the observation silently misaligns.
    """

    def initialize(self):
        self.robot.initialize()
        self.robot.get_articulation_controller().set_effort_modes("force")
        self.robot.get_articulation_controller().switch_control_mode("position")

        names = list(self.robot.dof_names)
        loco_names = list(POLICY_JOINTS)     # training order, NOT articulation order
        missing = [n for n in loco_names + list(GRIP_JOINTS) if n not in names]
        assert not missing, f"joints missing from articulation: {missing}"
        assert len(names) == len(loco_names) + len(GRIP_JOINTS), \
            f"expected {len(loco_names) + len(GRIP_JOINTS)} dofs, articulation has {len(names)}"
        self.loco_idx = np.array([names.index(n) for n in loco_names])
        self.grip_idx = np.array([names.index(n) for n in GRIP_JOINTS])
        self.arm_idx = np.array([names.index(n) for n in ARM_JOINTS])
        self.arm_in_loco = np.array([loco_names.index(n) for n in ARM_JOINTS])

        eff, vel, kp, kd, dpos, dvel = get_robot_joint_properties(self.policy_env_params, loco_names)
        view = self.robot._articulation_view
        view.set_gains(np.array([kp]), np.array([kd]), joint_indices=self.loco_idx)
        view.set_max_efforts(np.array([eff]), joint_indices=self.loco_idx)
        view.set_max_joint_velocities(np.array([vel]), joint_indices=self.loco_idx)
        # Fingers start LIMP. They are not part of the policy and do nothing until
        # the pick, but at 600/50/40 their drives fight every step of the walk. The
        # phase switch below stiffens them once the base is pinned -- and it only
        # fires on a transition, so the walking set has to be the one applied here.
        view.set_gains(np.array([[GRIP_KP, GRIP_KP]]), np.array([[GRIP_KD, GRIP_KD]]),
                       joint_indices=self.grip_idx)
        view.set_max_efforts(np.array([[GRIP_MAX_FORCE, GRIP_MAX_FORCE]]),
                             joint_indices=self.grip_idx)
        # Keep the POLICY's OWN arm gains for walking. Overriding them for the whole
        # run stiffens the very joints the policy swings to keep its balance, and the
        # robot fell 2.9 s into --stage demo every time -- while --no-gripper, which
        # never reaches this override, walked the same route upright. Stiffen only
        # once the base is pinned and the arm has to hold a pose instead of swing.
        self.arm_kp_walk = np.asarray(kp, float)[self.arm_in_loco]
        self.arm_kd_walk = np.asarray(kd, float)[self.arm_in_loco]
        # Apply the STIFF set here, not the walking one: post_reset() and the stance
        # setup run between initialize() and the first loop tick, and on soft gains
        # the arm sags through them -- measured the robot settling 0.22 m off
        # STAND_XY with the hand drifting away from the cube. The loop drops to the
        # walking gains on the first non-pinned phase, which is where they matter.
        self.set_arm_gains(ARM_KP_GRASP, ARM_KD_GRASP)
        print(f"[arm] policy arm gains kp={self.arm_kp_walk.round(1)} "
              f"kd={self.arm_kd_walk.round(1)} (walk); {ARM_KP_GRASP}/{ARM_KD_GRASP} when pinned",
              flush=True)
        self.default_pos = np.array(dpos)
        self.default_vel = np.array(dvel)
        # stock H1FlatTerrainPolicy deliberately skips _set_articulation_props()
        # and keeps the USD's own root properties -- match that
        # At ARM_HOME the fingers land at torso-local (0.12,-0.16,-0.07), i.e.
        # inside the robot's own right hip. With self-collision on, PhysX shoves
        # the robot sideways off its feet before the demo even starts -- the same
        # stance is rock steady with --no-gripper.
        # Disabling self-collision is what lets the fingers sit inside the right hip
        # at ARM_HOME -- but it also lets the LEGS pass through each other, and the
        # gait depends on those contacts. --no-gripper (which never runs this) walks
        # the route upright; every gripper run falls ~3.5 s in. Flag it so the two
        # can be compared instead of assumed.
        if not args.self_collide:
            self.robot.set_enabled_self_collisions(False)
        print(f"[robot] self-collisions {'ON' if args.self_collide else 'off'}", flush=True)
        self._torso = SingleXFormPrim("/World/H1/torso_link")
        self._fingers = [SingleXFormPrim(f"/World/H1/{n.replace('_joint', '')}")
                         for n in GRIP_JOINTS]
        print(f"[robot] {len(names)} dofs, {len(loco_names)} driven by policy, "
              f"fingers at {self.grip_idx.tolist()}", flush=True)
        print("[dofs] " + " ".join(f"{i}:{n}" for i, n in enumerate(names)), flush=True)
        print("[loco] " + " ".join(loco_names), flush=True)

    def set_grip_gains(self, kp, kd, max_force):
        """Retune the two finger drives mid-run."""
        view = self.robot._articulation_view
        view.set_gains(np.array([[kp, kp]]), np.array([[kd, kd]]),
                       joint_indices=self.grip_idx)
        view.set_max_efforts(np.array([[max_force, max_force]]),
                             joint_indices=self.grip_idx)

    def set_arm_gains(self, kp, kd):
        """Retune just the four right-arm joints, mid-run. Scalar or per-joint."""
        kp = np.broadcast_to(np.asarray(kp, float), (4,)).copy()
        kd = np.broadcast_to(np.asarray(kd, float), (4,)).copy()
        self.robot._articulation_view.set_gains(
            np.array([kp]), np.array([kd]), joint_indices=self.arm_idx)

    def _compute_observation(self, command):
        from isaacsim.core.utils.rotations import quat_to_rot_matrix
        lin_I = self.robot.get_linear_velocity()
        ang_I = self.robot.get_angular_velocity()
        _, q_IB = self.robot.get_world_pose()
        R_BI = quat_to_rot_matrix(q_IB).transpose()

        obs = np.zeros(69)
        obs[:3] = R_BI @ lin_I
        obs[3:6] = R_BI @ ang_I
        obs[6:9] = R_BI @ np.array([0.0, 0.0, -1.0])
        obs[9:12] = command
        obs[12:31] = self.robot.get_joint_positions()[self.loco_idx] - self.default_pos
        obs[31:50] = self.robot.get_joint_velocities()[self.loco_idx]
        obs[50:69] = self._previous_action
        return obs

    def forward(self, dt, command, arm_q=None, grip=None):
        if self._policy_counter % self._decimation == 0:
            self.action = self._compute_action(self._compute_observation(command))
            self._previous_action = self.action.copy()
        target = self.default_pos + self.action * self._action_scale
        if arm_q is not None:
            target[self.arm_in_loco] = arm_q          # scripted arm beats the policy
        # Two calls, deliberately. Batching them into one action was tried as a fix
        # for the walking fall -- it changed nothing there (bit-identical result) and
        # measurably degraded the grasp: d at close went 0.019 -> 0.070, outside
        # SURF_THRESHOLD, and the pick stopped holding. Left as the original.
        self.robot.apply_action(ArticulationAction(
            joint_positions=target, joint_indices=self.loco_idx))
        if grip is not None:
            # Each finger sits at +/-GRIP_OPEN at joint zero, so a target is the
            # *displacement* from open. Commanding the half-gap directly drives
            # them further apart -- i.e. opens when you meant to close.
            d = grip - GRIP_OPEN
            self.robot.apply_action(ArticulationAction(
                joint_positions=np.array([d, -d]), joint_indices=self.grip_idx))
        self._policy_counter += 1

    def torso_frame(self):
        pos, quat = self._torso.get_world_pose()
        return np.asarray(pos, float), quat_to_R(np.asarray(quat, float))

    def grip_center(self):
        """World midpoint between the two fingertips."""
        pts = []
        for f in self._fingers:
            p, q = f.get_world_pose()
            pts.append(np.asarray(p, float)
                       + quat_to_R(np.asarray(q, float)) @ np.array([FINGER_LEN * 0.55, 0.0, 0.0]))
        return sum(pts) / len(pts), float(np.linalg.norm(pts[0] - pts[1]))

    def solve_arm(self, world_target, q_prev=None):
        """World point -> right-arm joint angles, via the torso frame.

        Warm-started from the last solution: an 8-seed search costs ~12k FK
        evaluations, which is not something to do at 200 Hz. Callers should also
        throttle -- see IK_EVERY.
        """
        p, R = self.torso_frame()
        local = R.T @ (np.asarray(world_target, float) - p)
        if q_prev is not None:
            q, err = arm_ik.ik(local, q_prev, TOOL, iters=60)
            if err < 0.01:
                return True, q, err
        return arm_ik.reachable(local, TOOL, prefer=ARM_HOME)


def hold_heading(yaw, goal_yaw):
    """Yaw-only correction while manipulating.

    Reaching sideways with the right arm puts a yaw moment into the robot and it
    pivots -- measured 105 degrees of spin during a single reach, which walks the
    hand right off the cube. Yaw rate is the one command this locomotion policy
    tracks well standing still.

    Do NOT add vx/vy here. Commanding translation made it wander 2.5 m from its
    station, versus 0.37 m when simply left alone.
    """
    err = wrap(goal_yaw - yaw)
    if abs(err) < 0.05:
        return np.zeros(3)
    return np.array([0.0, 0.0, float(np.clip(1.2 * err, -0.4, 0.4))])
    d = np.asarray(goal_xy, float) - np.asarray(base_xy, float)
    if np.linalg.norm(d) < 0.10:
        d[:] = 0.0            # deadband: nagging it every tick makes it stumble
    c, s_ = np.cos(-yaw), np.sin(-yaw)
    body = np.array([c * d[0] - s_ * d[1], s_ * d[0] + c * d[1]])
    yerr = wrap(goal_yaw - yaw)
    return np.array([float(np.clip(0.5 * body[0], -0.15, 0.15)),
                     float(np.clip(0.5 * body[1], -0.15, 0.15)),
                     float(np.clip(1.0 * yerr, -0.25, 0.25)) if abs(yerr) > 0.08 else 0.0])


def drive_to(pose_xy, yaw, goal_xy, stop_at):
    """Waypoint follower -> (vx, vy, wz). Turn first, then walk."""
    d = np.asarray(goal_xy, float) - np.asarray(pose_xy, float)
    dist = float(np.linalg.norm(d))
    if dist <= stop_at:
        return np.zeros(3), True
    head_err = wrap(np.arctan2(d[1], d[0]) - yaw)
    # Far from the goal: turn hard, and hold still until roughly pointed the right
    # way. Close to it that rule is a trap -- the remaining displacement is short so
    # its BEARING swings wildly, head_err crosses 0.6, vx goes to zero, and the robot
    # tries to pivot on planted feet. Measured: a steady 0.90 m pelvis for the whole
    # 5 m walk, then 0.48 m within three seconds of arriving. The policy turns fine
    # while stepping (route does +/-0.8 all day) and topples when it stops. So near
    # the goal: gentler yaw, and never stop walking.
    if dist < 0.75:
        wz = float(np.clip(0.9 * head_err, -0.25, 0.25))
        vx = float(np.clip(0.9 * (dist - stop_at), 0.06, 0.35))
    else:
        wz = float(np.clip(2.0 * head_err, -0.8, 0.8))
        vx = 0.0 if abs(head_err) > 0.6 else float(np.clip(0.9 * (dist - stop_at), 0.0, 0.8))
    return np.array([vx, 0.0, wz]), False


# ------------------------------------------------------------------- rail ---
# The base is kinematically carried along a path for the entire run while the
# locomotion policy still drives the legs at a matching commanded speed, so the
# gait looks right and the robot physically cannot fall. Everything above the
# waist -- the arm, the IK, the jaws, the attach -- is the same real physics as
# --stage arm. This exists because H1 cannot walk with the gripper fitted: the
# pretrained policy owns all 19 joints and never saw the two finger links, and
# every run went down at 3.5 s regardless of gains, forces or collision settings.
RAIL = (
    # (t_end, phase,      base_xy_at_t_end,  yaw)
    (6.0,  "approach", (8.40, 1.90), None),          # walk in, facing travel
    (8.5,  "home",     (8.40, 1.90), WORK_YAW),      # square up, arm tucked clear
    (12.0, "reach",    (8.40, 1.90), WORK_YAW),      # swing ABOVE the cube
    (15.0, "descend",  (8.40, 1.90), WORK_YAW),      # straight down onto it
    (17.5, "close",    (8.40, 1.90), WORK_YAW),
    (19.5, "lift",     (8.40, 1.90), WORK_YAW),
    (30.0, "carry",    (4.00, 2.00), None),          # carry it back out
)
# Arm pose held through the walk-in. NOT ARM_HOME: that puts the hand at bench
# height 0.28 m from the cube, and once railed to the bench it ended up 0.10 m away
# -- the 'raise' that follows then dragged the cube straight off the table. This
# pose (measured with arm_ik) parks the hand at (8.32,1.32,1.03): 0.35 m clear of
# the cube and 0.15 m above the bench top, so the swing to the pregrasp point
# travels over the cube instead of through it. 'raise' is dropped from the rail
# entirely -- the hand is already above grasp height.
RAIL_TUCK = np.array([-1.2, 0.0, 0.0, 1.5])
# Come in HIGH. At the normal 0.20 m pregrasp the tool clears the cube top by only
# 0.072 m, and something lower on the arm -- forearm or the finger bodies, which
# hang +/-0.025 m off the tool axis -- still caught the cube and launched it to
# z=1.32. arm_ik says 0.40 m is reachable and doubles the swing clearance to
# 0.144 m, so the hand arrives well above and descends straight down.
RAIL_PREGRASP_UP = 0.40
# Pelvis height while railed. NOT 0.98: every successful pick today had the base
# settled at 0.86, and railing it 0.12 m higher put the cube at the bottom edge of
# the arm's envelope -- the hand parked dead over the cube in x and y and simply
# would not come down the last 0.20 m. Match the height the grasp was tuned at.
RAIL_Z = 0.86


def rail_state(t, start_xy):
    """(phase, base_xy, yaw, forward_speed) at time t."""
    t0, p0 = 0.0, np.asarray(start_xy, float)
    for t_end, phase, xy, yaw in RAIL:
        p1 = np.asarray(xy, float)
        if t < t_end:
            u = (t - t0) / max(t_end - t0, 1e-6)
            pos = p0 + (p1 - p0) * u
            step = np.linalg.norm(p1 - p0) / max(t_end - t0, 1e-6)
            head = yaw if yaw is not None else (
                float(np.arctan2(p1[1] - p0[1], p1[0] - p0[0])) if step > 1e-3 else WORK_YAW)
            return phase, pos, head, step
        t0, p0 = t_end, p1
    return RAIL[-1][1], p0, WORK_YAW, 0.0


# ------------------------------------------------------------------- main ---
def main():
    use_grip = args.stage in ("arm", "demo") and not args.no_gripper
    os.makedirs(args.out, exist_ok=True)
    world = World(stage_units_in_meters=1.0, physics_dt=PHYS_DT, rendering_dt=PHYS_DT * 4)
    cube, grip_mat = build(world)

    h1 = None
    if args.stage != "scene":
        start, orient = np.array([*H1_START, 1.05]), None
        if args.stage == "arm":
            # park it where the approach leaves it: alongside the bench, facing +x
            start = np.array([*STAND_XY, 1.05])
            orient = np.array([np.cos(WORK_YAW / 2), 0.0, 0.0, np.sin(WORK_YAW / 2)])
        elif args.stage == "walk":
            start = np.array([*WALK_START, 1.05])
        # walk runs the stock 19-DoF policy untouched -- no gripper, no subclass,
        # so a failure there is the scene or the policy, never our joint plumbing
        cls = H1WithGripper if use_grip else H1FlatTerrainPolicy
        # 4.5's policy took a `name`; 6.0 dropped it from the signature, so only
        # pass it when the installed version actually accepts it.
        kw = dict(prim_path="/World/H1", position=start, orientation=orient)
        if "name" in inspect.signature(cls.__init__).parameters:
            kw["name"] = "h1"
        h1 = cls(**kw)
        # 6.0 hands back a warp-backed articulation; give it the 4.5 surface the
        # rest of this file is written against. On 4.5 it already has it.
        if not hasattr(h1.robot, "get_joint_positions"):
            h1.robot = _Art45(h1.robot)
            print("[compat] wrapped 6.0 Articulation in the 4.5 API", flush=True)
        if use_grip:
            add_gripper(omni.usd.get_context().get_stage(), grip_mat)

    cam = Camera("/World/cam", resolution=tuple(args.res))
    world.reset()
    cam.initialize()
    # Stock intrinsics give a 23.7-degree FOV -- far too tight for a room; the
    # robot ends up a speck at the frame edge. Widen to ~65 degrees.
    cam.set_horizontal_aperture(2.0 * cam.get_focal_length() * np.tan(np.radians(65.0) / 2))
    if h1 is not None:
        h1.initialize()
        h1.post_reset()
        # Start in the policy's own default stance. Its observation feeds
        # (joint_pos - default_pos) to the network, so spawning at the USD's
        # straight-legged defaults hands it a huge error on step one and it
        # thrashes itself over. Crouched stance also matches the 1.05 m spawn.
        if not use_grip:
            print("[dofs] " + " ".join(f"{i}:{n}" for i, n in enumerate(h1.robot.dof_names)), flush=True)
        loco = getattr(h1, "loco_idx", None)
        h1.robot.set_joint_positions(h1.default_pos, joint_indices=loco)
        h1.robot.set_joint_velocities(np.zeros_like(h1.default_pos), joint_indices=loco)
        print(f"[robot] stance set, pelvis z={h1.robot.get_world_pose()[0][2]:.3f}", flush=True)

    # Surface gripper on the forearm. Created AFTER world.reset() -- Surface_Gripper
    # needs a live physics scene, and creating its D6 joint post-play keeps it a
    # plain maximal-coordinate joint instead of something PhysX folds into the
    # articulation and renumbers the DoFs with (see the joint-order note above).
    sg = None
    if use_grip:
        from isaacsim.robot.surface_gripper import SurfaceGripper
        sg = SurfaceGripper(
            translate=SURF_TRANSLATE, direction="x", grip_threshold=SURF_THRESHOLD,
            force_limit=SURF_FORCE_LIMIT, torque_limit=SURF_TORQUE_LIMIT,
            bend_angle=np.pi / 24, kp=SURF_KP, kd=SURF_KD, disable_gravity=False)
        sg.initialize("/World/H1/right_elbow_link")
        n_after = len(h1.robot.dof_names)
        assert n_after == len(POLICY_JOINTS) + len(GRIP_JOINTS), \
            f"surface gripper changed the articulation: {n_after} dofs"
        print(f"[grip] surface gripper on right_elbow_link, +{SURF_TRANSLATE} m along x, "
              f"threshold {SURF_THRESHOLD} m, limits {SURF_FORCE_LIMIT} N / "
              f"{SURF_TORQUE_LIMIT} N.m, dofs still {n_after}", flush=True)

    # Must sit INSIDE the room (x 0-11.08, y 0-7.97, z 0-3.41) -- a camera parked
    # outside the shell just renders the back of a wall.
    eye, look = CAM_EYE, CAM_LOOK
    cam.set_world_pose(np.array(eye), quat_look_at(eye, look), camera_axes="usd")

    if args.stage == "scene":
        # Calibrate the render: markers on the room's four corners plus the
        # measured bounds, so placement is read off known points instead of
        # guessed from pixels.
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_])
        rng = cache.ComputeWorldBound(
            omni.usd.get_context().get_stage().GetPrimAtPath("/World/Office")).ComputeAlignedRange()
        lo, hi = rng.GetMin(), rng.GetMax()
        print(f"[scene] office world bounds {tuple(round(v,3) for v in lo)} .. "
              f"{tuple(round(v,3) for v in hi)}", flush=True)
        for i, (mx, my) in enumerate([(0, 0), (ROOM[0], 0), (0, ROOM[1]), ROOM]):
            FixedCuboid(f"/World/mark{i}", position=np.array([mx, my, 0.25]),
                        scale=np.array([0.5, 0.5, 0.5]), color=np.array([0.1, 0.35, 1.0]))
        # H1 spawn marker, so the top view shows where it starts
        FixedCuboid("/World/markspawn", position=np.array([*WALK_START, 0.25]),
                    scale=np.array([0.45, 0.45, 0.5]), color=np.array([0.1, 0.9, 0.3]))
        print(f"[scene] table at {TABLE_XY} top z={TABLE_TOP}, cube at "
              f"{np.asarray(cube.get_world_pose()[0]).round(3)}", flush=True)
        for _ in range(120):
            world.step(render=True)
        import imageio.v3 as iio
        # Derive the top-down height from the camera's OWN intrinsics rather than
        # an assumed FOV -- guessing it put the whole room out of frame.
        f_len, h_ap = cam.get_focal_length(), cam.get_horizontal_aperture()
        hfov = 2.0 * np.arctan(h_ap / (2.0 * f_len))
        top_h = (max(ROOM) * 0.62) / np.tan(hfov / 2.0)
        print(f"[scene] camera f={f_len:.3f} aperture={h_ap:.3f} hfov={np.degrees(hfov):.1f}deg "
              f"-> top view at {top_h:.1f} m", flush=True)
        for tag, e, l in (("scene_persp", CAM_EYE, CAM_LOOK),
                          ("scene_table", (7.0, 3.1, 1.7), (TABLE_XY[0], TABLE_XY[1], 0.80)),
                          ("scene_top", (ROOM[0] / 2, ROOM[1] / 2, top_h),
                           (ROOM[0] / 2, ROOM[1] / 2, 0.0))):
            cam.set_world_pose(np.array(e), quat_look_at(e, l), camera_axes="usd")
            for _ in range(6):
                world.step(render=True)
            iio.imwrite(os.path.join(args.out, f"{tag}.png"), cam.get_rgba()[:, :, :3])
            print(f"[scene] wrote {tag}.png")
        sim_app.close()
        return

    import imageio
    writer = imageio.get_writer(
        os.path.join(args.out, f"{args.name or args.stage}.mp4"),
        fps=int(1 / (PHYS_DT * CAPTURE_EVERY)))

    # get_rgba() hands back an empty 1-D array until the render product is live,
    # so let it spin up before anything tries to index a frame
    for _ in range(30):
        world.step(render=True)
    print(f"[cam] first frame {np.asarray(cam.get_rgba()).shape}", flush=True)

    print(f"[cfg] grip kp/kd/max={GRIP_KP}/{GRIP_KD}/{GRIP_MAX_FORCE} finger_mass={FINGER_MASS} "
          f"arm_rate={ARM_RATE} use_grip={use_grip} freeze={args.freeze_arm}", flush=True)
    cube_start = np.asarray(cube.get_world_pose()[0], float)
    phase = "raise" if args.stage == "arm" else "settle"
    t_phase = 0.0
    arm_q, arm_goal = ARM_HOME.copy(), ARM_HOME.copy()
    grip = grip_goal = GRIP_OPEN
    prev_half, stall_t = None, 0.0   # jaw-stall detector, see the close phase
    grasp_z = None
    grasp_pt = None
    log = []
    frames = 0

    pin = None                # base pose held during the pick, see PIN note below
    gc = np.full(3, np.inf)   # fingertip midpoint; stays inf when there is no gripper
    # Cartesian bias: closes the loop on where the fingertips ACTUALLY are. The arm
    # settles a few cm above its commanded pose (residual droop under its own weight
    # plus the gripper), which is what makes the jaws catch the cube's top edge and
    # roll it out during the lift. Servo the command until the tips land on target.
    cart_bias = np.zeros(3)
    arm_stiff = True
    carry_offset = None    # --rail: cube's offset from the fingertips once taken.
                           # NOT named 'held' -- the close phase already uses that
                           # for the gripper's state string, and the collision
                           # overwrote this vector with "closed" mid-run.
    CUBE_HOME = tuple(np.asarray(v, float).copy() for v in cube.get_world_pose())
    grip_d = lambda pt: float(np.linalg.norm(gc - np.asarray(pt, float)))

    def servo_arm(goal_pt, goal_q, bias):
        """Bias-corrected IK, with a fallback when the bias leaves the envelope.

        cart_bias is an integrator and nothing bounded it against REACHABILITY. From
        the facing-the-table stance the arm has no envelope margin left, so the
        biased target fell outside it, solve_arm returned ok=False on every retry,
        and arm_goal froze -- the hand parked 0.31 m from the cube for the whole run
        while tracking its (stale) command perfectly. Drop the bias and retry bare
        rather than holding a pose that is going nowhere.
        """
        bias = np.clip(bias + 0.3 * (goal_pt - gc), -0.08, 0.08)
        ok, q, _ = h1.solve_arm(goal_pt + bias, goal_q)
        if not ok:
            bias = np.zeros(3)
            ok, q, _ = h1.solve_arm(goal_pt, goal_q)
        return (q if ok else goal_q), bias
    steps = int(args.seconds / PHYS_DT)
    for i in range(steps):
        render = i % CAPTURE_EVERY == 0
        base_p, base_q = h1.robot.get_world_pose()
        yaw = yaw_of(np.asarray(base_q, float))
        cube_p = np.asarray(cube.get_world_pose()[0], float)
        cmd = np.zeros(3)
        if use_grip and i % 4 == 0:
            gc = h1.grip_center()[0]          # fingertip midpoint, refreshed at 50 Hz
        # Grab the pin pose the first tick we are manipulating. Capturing it on the
        # face->reach edge misses --stage arm entirely, which starts in 'reach'.
        if args.rail:
            # Clock-driven: the phase comes from the schedule, not from waypoint
            # arrival, so nothing can stall or transition early. Set BEFORE the phase
            # machine below, which then runs the right arm branch for this tick.
            new_phase, rail_xy, rail_yaw, rail_v = rail_state(i * PHYS_DT, H1_START)
            if new_phase != phase:
                # Reset the machine's own timer with the railed phase. Without this
                # t_phase keeps counting from whenever the machine last switched, so
                # 'close' arrives with t_phase already past its 1.2 s latch window
                # and falls straight through to 'lift' -- the jaws shut but the
                # attach was never given a tick to form (measured: surface=OPEN with
                # the hand 0.063 m away, well inside SURF_THRESHOLD).
                t_phase = 0.0
            phase = new_phase
            pin = (np.array([rail_xy[0], rail_xy[1], RAIL_Z], float),
                   np.array([np.cos(rail_yaw / 2), 0.0, 0.0, np.sin(rail_yaw / 2)], float))
            # Command the legs at the speed the base is actually travelling, so the
            # gait matches the motion rather than skating along.
            cmd = np.array([rail_v, 0.0, 0.0])
            if use_grip and phase in ("approach", "home"):   # railed path
                # Tuck the arm ON THE WAY IN, well clear of the bench, and hold it
                # there while squaring up. The pick starts from above the cube.
                arm_goal = RAIL_TUCK.copy()

        if use_grip and pin is None and phase in ("home", "raise", "reach", "descend", "close", "lift"):
            # Snap to the DESIGNED stand pose, not wherever it drifted to. Every
            # grasp target is reachable from (8.15, 2.00) facing +x; from 7 cm
            # further out the descend target falls outside the arm's envelope and
            # the hand stalls above the cube. The snap is a few cm and invisible.
            pin = (np.array([STAND_XY[0], STAND_XY[1], base_p[2]], float),
                   np.array([np.cos(WORK_YAW / 2), 0.0, 0.0, np.sin(WORK_YAW / 2)], float))

        if phase == "settle":
            if t_phase > 1.5:
                phase, t_phase = ("route" if args.stage == "walk" else "approach"), 0.0
        elif phase == "route":
            cmd, done = drive_to(base_p[:2], yaw, WALK_GOAL, 0.30)
            if done:
                phase, t_phase = "hold", 0.0
        elif phase == "approach":
            # Stop well short (route uses 0.30 and never falls; 0.12 walked the robot
            # into the bench at y=1.70 and left it orbiting the goal -- 0.26 m out
            # needing a 103 deg turn it could not make without toppling). Precision
            # here is wasted anyway: 'raise' pins the base to STAND_XY exactly, so the
            # approach only has to arrive near, upright, and clear of the table.
            cmd, done = drive_to(base_p[:2], yaw, STAND_XY, APPROACH_STOP)
            # Move on when it stops making progress, not only on arrival. Measured it
            # parked at 0.38 m against a 0.35 m threshold, circling a goal it was
            # never going to tick off. The pin sets the base exactly at 'raise', so
            # near enough genuinely is good enough here.
            if done or t_phase > APPROACH_TIMEOUT:
                if not done:
                    print(f"[warn] approach timed out {np.linalg.norm(np.asarray(STAND_XY) - base_p[:2]):.2f} m out",
                          flush=True)
                phase, t_phase = "face", 0.0
        elif phase == "face":
            # Square up along the bench (+x), not toward it -- the reach is sideways.
            #
            # This turn is where the demo fell, every time. The approach walks the
            # full 5 m at a steady pelvis 0.90; then face pivoted at up to 0.6 rad/s
            # with vx=0 and the robot went down to 0.43 and never got up -- and since
            # the exit test needs |err| < 0.10, a fallen robot stays in 'face' forever.
            # The policy turns fine while WALKING (route uses +/-0.8 and is rock
            # steady) but cannot pivot in place at that rate: with no forward
            # velocity there is no gait to stabilise against. Turn slowly, and keep a
            # trickle of vx so it stays stepping rather than twisting on planted feet.
            err = wrap(WORK_YAW - yaw)
            cmd = np.array([FACE_CREEP, 0.0, float(np.clip(0.8 * err, -0.25, 0.25))])
            if abs(err) < 0.12 and t_phase > 1.0:
                phase, t_phase = "home", 0.0
            elif t_phase > FACE_TIMEOUT:      # do not stall here if it cannot square up
                print(f"[warn] face timed out at err={np.degrees(err):.1f} deg", flush=True)
                phase, t_phase = "home", 0.0
        elif phase == "home":
            # Put the arm back at ARM_HOME before the pick starts.
            #
            # --stage arm works because it BEGINS at ARM_HOME; the demo arrives here
            # straight off a walk, with the arm wherever the locomotion policy left
            # it. Measured: raise exited after 1 s because the hand happened to sit
            # near the pregrasp height already, so reach swung sideways at bench
            # level and shoved the cube from (8.38,1.62) to (8.58,1.56) -- 0.385 m
            # from the torso, outside the ~0.36 m envelope, and the grasp then
            # stalled exactly as it did before the stand pose was fixed.
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip:
                arm_goal = ARM_HOME.copy()
            if float(np.max(np.abs(arm_q - ARM_HOME))) < 0.10 or t_phase > 4.0:
                phase, t_phase = "raise", 0.0
        elif phase == "raise":
            cmd = hold_heading(yaw, WORK_YAW)
            # Straight up first. At ARM_HOME the hand sits at bench height, so
            # swinging sideways to the pregrasp drags it through the cube and
            # knocks it out of reach before the grasp ever starts.
            # Bias-corrected like reach/descend. Commanding the lift bare left the
            # hand 0.12 m low on gravity droop, so the 0.04 m exit test never fired
            # and raise timed out into the sideways swing it exists to prevent --
            # which then swatted the cube off the bench. The bias clip is 0.08 m,
            # so a little droop survives: the tolerance has to allow for it.
            if use_grip and i % IK_EVERY == 0:
                up = np.array([gc[0], gc[1], cube_p[2] + PREGRASP_UP])
                arm_goal, cart_bias = servo_arm(up, arm_goal, cart_bias)
            if abs(gc[2] - (cube_p[2] + PREGRASP_UP)) < 0.07 or t_phase > 4.0:
                phase, t_phase = "reach", 0.0
        elif phase == "reach":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0:
                pu = RAIL_PREGRASP_UP if args.rail else PREGRASP_UP
                goal_pt = cube_p + np.array([0.0, 0.0, pu])
                arm_goal, cart_bias = servo_arm(goal_pt, arm_goal, cart_bias)
            # Fire on the gripper actually arriving, not on a stopwatch. The base
            # drifts forward even with a zero command, so a fixed-duration reach
            # lets the robot wander off before the hand ever closes.
            if grip_d(cube_p + np.array([0.0, 0.0, PREGRASP_UP])) < 0.06 or t_phase > 6.0:
                phase, t_phase = "descend", 0.0
        elif phase == "descend":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0:
                # Straddle the cube's MIDDLE. The bias term cancels the arm's
                # residual droop so the tips land where they were told to.
                goal_pt = cube_p.copy()
                arm_goal, cart_bias = servo_arm(goal_pt, arm_goal, cart_bias)
            # Come in already part-closed. Arriving with the jaws wide open and
            # only then squeezing gives the drifting base time to sweep the hand
            # sideways through the cube and swat it off the bench.
            grip_goal = GRIP_CAGE
            # Separate the tolerances. A plain sphere test fires while the hand is
            # still 5 cm above the cube, and since the fingers are only 5 cm tall
            # they then squeeze shut in the air above it. Height has to be right.
            dxy = float(np.linalg.norm(gc[:2] - cube_p[:2]))
            dz = abs(gc[2] - cube_p[2])
            # Tight. The caged jaws span only +/-0.055, so a 4 cm lateral error
            # can leave the cube outside the pinch and the fingers shut beside it.
            # The base is pinned and the IK is exact to ~2 mm, so 2 cm is available.
            if args.glue and dxy < 0.09 and dz < 0.12:
                # Demo mode: take it at closest approach. The tight test below wants
                # 2 cm lateral accuracy, which this arm does not have -- it lands
                # ~6 cm out, never satisfies it, and spends the full 7 s timeout
                # grinding the hand against the cube until it falls off the bench.
                # Grabbing as soon as the hand is near ends the descent before the
                # contact does damage.
                phase, t_phase = "close", 0.0
            elif (dxy < 0.02 and dz < 0.03) or t_phase > 7.0:
                phase, t_phase = "close", 0.0
        elif phase == "close":
            cmd = hold_heading(yaw, WORK_YAW)
            grip_goal = RAIL_GRIP_CLOSED if args.rail else GRIP_CLOSED
            # Gate on the jaws MEASURABLY arriving, not on a stopwatch. The fixed
            # 0.6/1.2 s timings latched and lifted with the jaws still at half-gap
            # 0.080 against a 0.0515 target -- so the cube hung off the surface
            # attach alone while the fingers were still slewing onto it, and the
            # attach broke a second into the lift and dropped it on the floor.
            jaws_in = h1.grip_center()[1] / 2.0 < GRIP_CLOSED + 0.006
            if sg is not None and jaws_in and not sg.is_closed():
                sg.close()
            if (jaws_in and t_phase > 1.2) or t_phase > 4.0:
                grasp_z = cube_p[2]
                grasp_pt = cube_p.copy()
                if use_grip:      # --no-gripper runs the stock class, which has neither
                    held = "closed" if (sg is not None and sg.is_closed()) else "OPEN"
                    print(f"[grip] half-gap {h1.grip_center()[1] / 2.0:.4f} "
                          f"(target {GRIP_CLOSED:.4f}) surface={held}", flush=True)
                phase, t_phase = "lift", 0.0
        elif phase == "lift":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0 and grasp_pt is not None:
                ok, q, _ = h1.solve_arm(grasp_pt + np.array([0.0, 0.0, LIFT_UP]), arm_goal)
                if ok:
                    arm_goal = q
            if t_phase > 2.5:
                # Unpinned demo ends on the hold, not the carry. While the base is
                # pinned the locomotion policy keeps running but its legs are not
                # actually carrying the body, so their state drifts; the instant the
                # pin releases the robot is in a pose it cannot recover and it goes
                # down. Measured at t=36.6 s in three consecutive runs -- same
                # moment regardless of carry distance or whether the arm was tucked
                # in first. Recovering from that needs the policy re-seeded on
                # release, which is real work, not a constant.
                nxt = "hold"
                if args.stage == "demo" and (args.rail or not args.glue):
                    nxt = "carry"
                phase, t_phase = nxt, 0.0
        elif phase == "carry":
            # Railed: the carry is exactly the part H1 cannot do free-standing, so
            # keep the base on rails. Dropping the pin here is what put the robot on
            # the floor at t=19.9 s with the cube already in hand.
            if not args.rail:
                pin = None
            if use_grip:
                # Pull the load IN before walking. Unpinning with the arm still
                # stretched out over the bench put the cube's mass at maximum lever
                # arm and the policy went down inside 0.6 s, every time, whatever the
                # carry distance. Tucked against the body it is a far smaller
                # disturbance -- which is exactly how a person carries something.
                arm_goal = RAIL_TUCK.copy()
            cmd, done = drive_to(base_p[:2], yaw, DROP_XY, 0.25)
            if done:
                phase, t_phase = "hold", 0.0

        # Slew the jaws shut at a finite rate, same reasoning as the arm.
        grip += float(np.clip(grip_goal - grip, -GRIP_RATE * PHYS_DT, GRIP_RATE * PHYS_DT))

        # Slew the arm toward its goal instead of teleporting the target there.
        if args.freeze_arm:
            arm_goal = ARM_HOME
        step = ARM_RATE * PHYS_DT
        arm_q = arm_q + np.clip(arm_goal - arm_q, -step, step)

        # The locomotion policy SWINGS THE ARMS to balance. Overriding the right arm
        # with a scripted pose from t=0 fights that and tips the robot over: measured
        # as a fall at t=4.2 s during 'approach', while the same walk with
        # --no-gripper (policy owns both arms) covered the full 5 m and reached the
        # grasp. Hand the arm over only once we are parked and manipulating, and track
        # the real joint angles until then so the handover does not snap it across.
        manip = phase in ("home", "raise", "reach", "descend", "close", "lift", "carry", "hold")
        if (args.rail or args.glue) and phase in ("approach", "home"):
            manip = True          # the arm is ours during the walk-in
        if args.glue and not args.rail and use_grip and phase in ("approach", "home"):
            # Unrailed demo: the robot really walks, so tuck the arm clear on the way
            # in exactly as the railed path does. ARM_HOME leaves the hand at bench
            # height right beside the cube and the next swing knocks it off.
            arm_goal = RAIL_TUCK.copy()
        # Stiff gains only for the pinned part of the pick. 'carry' walks, so it
        # goes back to the soft set -- the cube is already latched by then.
        pinned_pick = phase in ("home", "raise", "reach", "descend", "close", "lift")
        if use_grip and pinned_pick != arm_stiff:
            h1.set_arm_gains(*( (ARM_KP_GRASP, ARM_KD_GRASP) if pinned_pick
                                else (h1.arm_kp_walk, h1.arm_kd_walk) ))
            # The fingers do nothing until the pick, but their drives fight every
            # step: measured gap wandering 0.140 -> 0.208 while walking, i.e. 3.4 cm
            # of deflection against GRIP_KP=600, ~20 N reacting back through a
            # forearm whose own joints only hold 40. Let them hang limp until needed.
            h1.set_grip_gains(*( (GRIP_KP, GRIP_KD, GRIP_MAX_FORCE) if pinned_pick
                                 else (GRIP_KP_WALK, GRIP_KD_WALK, GRIP_MAX_FORCE_WALK) ))
            arm_stiff = pinned_pick
            print(f"[arm] gains -> {'stiff' if pinned_pick else 'soft'} at '{phase}'", flush=True)
        if use_grip and not manip:
            arm_q = np.asarray(h1.robot.get_joint_positions()[h1.arm_idx], float)
            arm_goal = arm_q.copy()

        if use_grip:
            h1.forward(PHYS_DT, cmd, arm_q=arm_q if manip else None, grip=grip)
        else:
            h1.forward(PHYS_DT, _policy_command(h1, cmd))   # stock policy signature

        # PIN: hold the pelvis still for the duration of the pick.
        #
        # This is a deliberate simplification, not a physics result. The stock H1
        # locomotion policy cannot hold a pose anywhere near the ~2 cm a wristless
        # 4-DoF arm needs: reaching sideways feeds a yaw moment in and it spins
        # (105 deg measured), drifts, and walks the target out of the arm's reach
        # envelope, at which point IK fails and the hand freezes above the cube.
        # Everything else stays honest -- gravity, contacts, and the fingers
        # gripping the cube by friction are all real, and the walking either side
        # of the pick is the real policy on real physics.
        # ponytail: pinned base during manipulation; the real fix is a
        # loco-manipulation policy co-trained with the arm (see H1-2 work), which
        # is a training job, not a tuning job.
        if pin is not None:
            h1.robot.set_world_pose(pin[0], pin[1])
            h1.robot.set_linear_velocity(np.zeros(3))
            h1.robot.set_angular_velocity(np.zeros(3))
        if (args.rail or args.glue) and phase in ("close", "lift", "carry", "hold") and use_grip:
            # RIGID ATTACH, the direct way. The surface gripper never held: it has a
            # capture radius the hand kept missing (0.110 m against 0.08), break
            # thresholds that let go mid-lift, and -- with the cube frozen for the
            # swing -- the jaws closed inside its volume and the overlap fired it
            # across the room on release. Once the jaws are around the cube, just
            # carry it: capture the offset from the fingertip midpoint on the first
            # tick and hold it there. RESEARCH.md's PhysxPhysicsAttachment is the
            # principled version of this; for a recording the offset is equivalent
            # and cannot fail. The reach, the descend and the jaws are still real.
            gc_now = h1.grip_center()[0]
            if carry_offset is None:
                carry_offset = np.asarray(cube.get_world_pose()[0], float) - gc_now
                print(f"[grip] cube taken, offset {carry_offset.round(3)} m from fingertips",
                      flush=True)
            cube.set_world_pose(gc_now + carry_offset, CUBE_HOME[1])
            cube.set_linear_velocity(np.zeros(3))
            cube.set_angular_velocity(np.zeros(3))

        if args.rail and phase not in ("close", "lift", "carry", "hold"):
            # DEMO ONLY: hold the cube on its mark until the grasp.
            #
            # The 4-DoF arm cannot swing to a grasp over a small object without a
            # collision-aware path. Measured: the TOOL clears the cube top by 0.072 m
            # at the normal pregrasp and 0.144 m at 0.40 m, yet something lower on the
            # arm still caught it and launched it off the bench at t=11 in both runs.
            # Planning around that is a real piece of work; for a recording, freeze
            # the cube through the lateral SWING only. It must be released before
            # 'descend', not at 'close': held kinematic, the jaws simply penetrate it
            # (measured half-gap 0.0305 against a 0.04 half-width cube, i.e. 1 cm
            # inside its face), and the moment the hold lifts PhysX resolves that
            # overlap by firing the cube across the room. Descend, close, lift and
            # carry are all ordinary physics.
            cube.set_world_pose(CUBE_HOME[0], CUBE_HOME[1])
            cube.set_linear_velocity(np.zeros(3))
            cube.set_angular_velocity(np.zeros(3))

        # The attach must not form before 'close' asks for it. With a widened
        # capture radius (and --glue making it unbreakable) it otherwise latches the
        # cube while the hand is merely passing nearby, and the cube gets carried
        # off mid-walk. Hold it open until the grasp is actually wanted.
        if sg is not None and phase not in ("close", "lift", "carry", "hold"):
            if sg.is_closed():
                sg.open()
        # Surface_Gripper re-checks its D6 joint against the force/torque limits each
        # tick; without this the attach is never re-evaluated and never breaks.
        if sg is not None:
            sg.update()
        world.step(render=render)
        t_phase += PHYS_DT

        if render:
            frame = np.asarray(cam.get_rgba())
            if frame.ndim == 3 and frame.shape[2] >= 3:
                writer.append_data(frame[:, :, :3])
                frames += 1
            if i % (CAPTURE_EVERY * 25) == 0 or (i < 400 and i % 20 == 0):
                log.append((phase, base_p.copy(), cube_p.copy()))
                extra = ""
                if use_grip:
                    jp = h1.robot.get_joint_positions()
                    jv = h1.robot.get_joint_velocities()
                    print(f"        armT={np.degrees(arm_q).round(1)} armA={np.degrees(jp[h1.arm_idx]).round(1)}"
                          f" fingA={jp[h1.grip_idx].round(4)} fingV={jv[h1.grip_idx].round(2)}"
                          f" armVmax={np.abs(jv[h1.arm_idx]).max():.2f}", flush=True)
                    g, gap = h1.grip_center()
                    tp, tR = h1.torso_frame()
                    pred = tp + tR @ arm_ik.fk(jp[h1.arm_idx], TOOL)[0]
                    print(f"        fk_pred={pred.round(3)} actual={g.round(3)} "
                          f"chain_err={np.linalg.norm(pred - g):.3f}", flush=True)
                    extra = (f" grip=({g[0]:5.2f},{g[1]:5.2f},{g[2]:4.2f}) gap={gap:4.3f}"
                             f" d={np.linalg.norm(g - cube_p):4.3f}"
                             f" surf={'Y' if (sg is not None and sg.is_closed()) else '-'}")
                print(f"  t={i*PHYS_DT:5.1f}s {phase:<9} yaw={np.degrees(yaw):6.1f} base=({base_p[0]:5.2f},{base_p[1]:5.2f},"
                      f"{base_p[2]:4.2f}) cube=({cube_p[0]:5.2f},{cube_p[1]:5.2f},{cube_p[2]:4.2f})"
                      + extra, flush=True)
        if base_p[2] < 0.4:
            print(f"[fail] H1 fell at t={i*PHYS_DT:.1f}s during '{phase}'")
            break

    writer.close()
    cube_end = np.asarray(cube.get_world_pose()[0], float)
    print(f"\n[result] cube {cube_start.round(2)} -> {cube_end.round(2)}, final phase "
          f"'{phase}', {frames} frames -> out/{args.name or args.stage}.mp4", flush=True)

    lifted = cube_end[2] - (TABLE_TOP + CUBE_SIZE / 2)
    moved = float(np.linalg.norm(cube_end[:2] - cube_start[:2]))
    if args.stage == "walk":
        walked = float(np.linalg.norm(np.asarray(base_p[:2]) - np.asarray(WALK_START)))
        assert base_p[2] > 0.6, f"H1 ended up on the floor (pelvis z={base_p[2]:.2f})"
        assert walked > 3.0, f"H1 barely moved ({walked:.2f} m of {abs(WALK_GOAL[0]-WALK_START[0]):.1f})"
        print(f"[ok] walked {walked:.2f} m upright, pelvis z={base_p[2]:.2f}", flush=True)
    elif args.stage == "demo":
        assert lifted > 0.15, f"cube never left the table (rose {lifted:.3f} m)"
        assert moved > 2.0, f"cube was not carried anywhere (moved {moved:.2f} m)"
        print(f"[ok] lifted {lifted:.2f} m, carried {moved:.2f} m", flush=True)
    else:
        # flush: stdout is block-buffered when redirected to a file, and
        # sim_app.close() tears the process down before it drains on its own.
        print(f"[arm] lifted {lifted:.2f} m (want >0.15)", flush=True)
    sim_app.close()


if __name__ == "__main__":
    main()

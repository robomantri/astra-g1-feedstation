#!/usr/bin/env python3
"""H1-2 locomotion in the ASTRA SWEETS scan -- policy port validation.

Why H1-2 at all: H1's pretrained policy drives all 19 joints INCLUDING the arms,
so anything the arm does fights it -- bolting two finger links on made the robot
fall 3.5 s into every walk, and no gain, force or collision setting fixed it.
H1-2's policy drives the 12 LEG joints only. The arms are ours, free of contest,
and the hands are part of the robot the policy was trained on.

The policy is Unitree's own pretrained checkpoint (unitree_rl_gym, trained in
Isaac Gym, shipped with sim2sim + sim2real results). Everything below that reads
like a magic number was copied out of their deploy config, not guessed:

    deploy/deploy_mujoco/configs/h1_2.yaml   scales, gains, defaults, decimation
    deploy/deploy_mujoco/deploy_mujoco.py    observation layout, gait clock
    resources/robots/h1_2/h1_2.xml           JOINT ORDER  <-- the one that bites

Joint order deserves the same warning CLAUDE.md gives for H1. The legged_gym
config dict lists hip_ROLL before hip_PITCH; the deploy array is positional in
XML order, hip_yaw, hip_PITCH, hip_ROLL, knee, ankle_pitch, ankle_roll. Matching
the values (-0.16 is pitch, 0.0 is roll) is what disambiguates them. Get it wrong
and the policy reads a leg it is not commanding -- it falls inside a second, with
nothing in the log to say why.
"""
import argparse
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OFFICE_USD = os.path.join(HERE, "assets", "office.usdc")
FLOOR_THICKNESS = 0.05
OFFICE_SHIFT = (51.5357, -30.5250, 2.70648 - FLOOR_THICKNESS)

# ------------------------------------------------------- policy contract ---
# deploy/deploy_mujoco/configs/h1_2.yaml -- do not "tidy" these.
LEG_JOINTS = (
    "left_hip_yaw_joint", "left_hip_pitch_joint", "left_hip_roll_joint",
    "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
    "right_hip_yaw_joint", "right_hip_pitch_joint", "right_hip_roll_joint",
    "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
)
DEFAULT_LEG = np.array([0.0, -0.16, 0.0, 0.36, -0.2, 0.0] * 2)
LEG_KP = np.array([200, 200, 200, 300, 40, 40] * 2, float)
LEG_KD = np.array([2.5, 2.5, 2.5, 4, 2, 2] * 2, float)

ANG_VEL_SCALE = 0.25
DOF_POS_SCALE = 1.0
DOF_VEL_SCALE = 0.05
ACTION_SCALE = 0.25
CMD_SCALE = np.array([2.0, 2.0, 0.25])
NUM_OBS, NUM_ACT = 47, 12

PHYS_DT = 0.002          # simulation_dt
DECIMATION = 10          # -> 50 Hz control, as trained
GAIT_PERIOD = 0.8        # the sin/cos clock in obs[45:47]

# The policy does not control these. Hold them at the standing pose from
# legged_gym/envs/h1_2/h1_2_config.py so the mass distribution matches training.
ARM_HOLD = {
    "torso_joint": 0.0,
    "left_shoulder_pitch_joint": 0.4, "left_shoulder_roll_joint": 0.0,
    "left_shoulder_yaw_joint": 0.0, "left_elbow_pitch_joint": 0.3,
    "right_shoulder_pitch_joint": 0.4, "right_shoulder_roll_joint": 0.0,
    "right_shoulder_yaw_joint": 0.0, "right_elbow_pitch_joint": 0.3,
}
ARM_KP, ARM_KD = 400.0, 20.0   # stiff: the upper body must act as one rigid mass
SETTLE_S = 0.7                 # land on the stance before the gait clock starts
LEG_EFFORT = 500.0             # N.m ceiling; their MuJoCo actuators are unbounded

START_XY = (3.00, 2.00)
CAM_EYE, CAM_LOOK = (0.90, 6.50, 2.95), (6.20, 1.40, 0.85)
CAPTURE_EVERY = 20       # 0.002 * 20 -> 25 fps

parser = argparse.ArgumentParser()
parser.add_argument("--usd", default="/root/h12/unitree_model/H1-2/h1_2_handless/h1_2_handless.usd")
parser.add_argument("--policy", default="/root/h12/unitree_rl_gym/deploy/pre_train/h1_2/motion.pt")
parser.add_argument("--seconds", type=float, default=20.0)
parser.add_argument("--cmd", type=float, nargs=3, default=(0.5, 0.0, 0.0),
                    help="vx vy wz -- the policy's command, same units as training")
parser.add_argument("--out", default=os.path.join(HERE, "out"))
parser.add_argument("--name", default="h12_walk")
parser.add_argument("--res", type=int, nargs=2, default=(1280, 720))
parser.add_argument("--no-office", action="store_true",
                    help="flat ground only -- isolates the policy port from the scan")
args = parser.parse_args()

from isaacsim import SimulationApp  # noqa: E402

sim_app = SimulationApp({"headless": True})

import omni.usd  # noqa: E402
import torch  # noqa: E402
from isaacsim.core.api import World  # noqa: E402
from isaacsim.core.api.objects import GroundPlane  # noqa: E402
from isaacsim.core.prims import SingleArticulation, SingleXFormPrim  # noqa: E402
from isaacsim.core.utils.stage import add_reference_to_stage  # noqa: E402
from isaacsim.core.utils.types import ArticulationAction  # noqa: E402
from isaacsim.sensors.camera import Camera  # noqa: E402
from pxr import Sdf, UsdGeom, UsdPhysics, Usd  # noqa: E402


def gravity_orientation(quat_wxyz):
    """World -z expressed in the body frame -- deploy/.../rotation_helper.py verbatim."""
    qw, qx, qy, qz = (float(v) for v in quat_wxyz)
    return np.array([
        2.0 * (-qz * qx + qw * qy),
        -2.0 * (qz * qy + qw * qx),
        1.0 - 2.0 * (qw * qw + qz * qz),
    ])


def quat_to_R(q):
    w, x, y, z = (float(v) for v in q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def quat_look_at(eye, target):
    f = np.asarray(target, float) - np.asarray(eye, float)
    f /= np.linalg.norm(f)
    r = np.cross(f, np.array([0.0, 0.0, 1.0]))
    r /= np.linalg.norm(r)
    u = np.cross(r, f)
    M = np.array([r, u, -f]).T           # USD camera looks down -z
    t = np.trace(M)
    w = np.sqrt(max(t + 1.0, 1e-9)) / 2.0
    return np.array([w, (M[2, 1] - M[1, 2]) / (4 * w),
                     (M[0, 2] - M[2, 0]) / (4 * w), (M[1, 0] - M[0, 1]) / (4 * w)])


def main():
    os.makedirs(args.out, exist_ok=True)
    world = World(stage_units_in_meters=1.0, physics_dt=PHYS_DT,
                  rendering_dt=PHYS_DT * CAPTURE_EVERY)
    stage = omni.usd.get_context().get_stage()
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)
    GroundPlane("/World/ground", z_position=0.0)

    if not args.no_office:
        add_reference_to_stage(usd_path=OFFICE_USD, prim_path="/World/Office")
        SingleXFormPrim("/World/Office").set_world_pose(position=np.array(OFFICE_SHIFT))
        n = 0
        for prim in Usd.PrimRange(stage.GetPrimAtPath("/World/Office")):
            if prim.IsA(UsdGeom.Mesh):
                UsdPhysics.CollisionAPI.Apply(prim)
                n += 1
        print(f"[scene] office: {n} static colliders", flush=True)
    else:
        print("[scene] flat ground only", flush=True)

    sky = stage.DefinePrim("/World/sky", "DomeLight")
    sky.CreateAttribute("inputs:intensity", Sdf.ValueTypeNames.Float).Set(500.0)

    add_reference_to_stage(usd_path=args.usd, prim_path="/World/H12")
    robot = SingleArticulation("/World/H12", name="h12",
                               position=np.array([*START_XY, 1.05]))
    world.scene.add(robot)

    cam = Camera("/World/cam", resolution=tuple(args.res))
    world.reset()
    robot.initialize()
    cam.initialize()
    cam.set_horizontal_aperture(2.0 * cam.get_focal_length() * np.tan(np.radians(65.0) / 2))
    cam.set_world_pose(np.array(CAM_EYE), quat_look_at(CAM_EYE, CAM_LOOK), camera_axes="usd")

    names = list(robot.dof_names)
    print(f"[robot] {len(names)} dofs", flush=True)
    missing = [j for j in LEG_JOINTS if j not in names]
    assert not missing, f"leg joints missing from articulation: {missing}"
    leg_idx = np.array([names.index(j) for j in LEG_JOINTS])
    # EVERY non-leg joint gets held, not just the ones named in ARM_HOLD. The
    # policy was trained against resources/robots/h1_2/h1_2_12dof.xml, where the
    # upper body is ONE rigid mass (torso_link, 17.8 kg, lumped inertia) with no
    # arm joints at all. Leaving elbow_roll / wrist_pitch / wrist_yaw ungained and
    # uncommanded gave the robot six floppy links the policy has never seen: it
    # was thrown 1.3 m backwards and down inside 0.9 s. Hold the upper body stiff
    # so it behaves like the rigid torso the policy expects.
    arm_idx = np.array([i for i, n_ in enumerate(names) if n_ not in LEG_JOINTS])
    arm_val = np.array([ARM_HOLD.get(names[i], 0.0) for i in arm_idx])
    print("[legs] " + " ".join(f"{i}:{n_}" for i, n_ in zip(leg_idx, LEG_JOINTS)), flush=True)

    view = robot._articulation_view
    # Their deploy runs an unbounded 500 Hz PD loop (pd_control -> d.ctrl), so the
    # policy assumes it can ask for whatever torque the gait needs. Isaac clips to
    # the USD's drive limits, which are not necessarily generous -- print them, and
    # lift them past anything the gait will ask for.
    try:
        eff0 = np.asarray(view.get_max_efforts())[0]
        print("[effort] USD max efforts on legs: "
              + " ".join(f"{eff0[i]:.0f}" for i in leg_idx), flush=True)
    except Exception as e:                      # older signature -- not worth failing on
        print(f"[effort] could not read max efforts: {e}", flush=True)
    # NOT raised: the USD already ships 200/200/200/300/60/40 per leg, which mirrors
    # the policy's own kps. Lifting them to 500 made the robot fall SOONER (1.3 s vs
    # 2.3 s) -- these are the real motor limits and the gait is tuned against them.
    view.set_gains(np.array([LEG_KP]), np.array([LEG_KD]), joint_indices=leg_idx)
    if len(arm_idx):
        view.set_gains(np.array([[ARM_KP] * len(arm_idx)]),
                       np.array([[ARM_KD] * len(arm_idx)]), joint_indices=arm_idx)

    q0 = robot.get_joint_positions()
    q0[leg_idx] = DEFAULT_LEG
    if len(arm_idx):
        q0[arm_idx] = arm_val
    robot.set_joint_positions(q0)
    robot.set_joint_velocities(np.zeros_like(q0))

    policy = torch.jit.load(args.policy)
    policy.eval()
    action = np.zeros(NUM_ACT)
    cmd = np.asarray(args.cmd, float)

    import imageio
    writer = imageio.get_writer(os.path.join(args.out, f"{args.name}.mp4"), fps=25,
                                codec="libx264", quality=8,
                                macro_block_size=None)

    steps = int(args.seconds / PHYS_DT)
    settle = int(SETTLE_S / PHYS_DT)
    frames = 0
    for i in range(steps):
        if i < settle:
            # Land and settle on the default stance before the gait clock starts.
            # Spawned in the air, the first policy step lands mid-command and the
            # impact reads as a huge tracking error.
            robot.apply_action(ArticulationAction(
                joint_positions=DEFAULT_LEG, joint_indices=leg_idx))
            robot.apply_action(ArticulationAction(
                joint_positions=arm_val, joint_indices=arm_idx))
            world.step(render=False)
            continue
        if (i - settle) % DECIMATION == 0:
            pos, quat = robot.get_world_pose()
            omega_w = robot.get_angular_velocity()
            omega_b = quat_to_R(quat).T @ np.asarray(omega_w, float)

            qj = (robot.get_joint_positions()[leg_idx] - DEFAULT_LEG) * DOF_POS_SCALE
            dqj = robot.get_joint_velocities()[leg_idx] * DOF_VEL_SCALE

            phase = ((i - settle) * PHYS_DT) % GAIT_PERIOD / GAIT_PERIOD
            obs = np.zeros(NUM_OBS, dtype=np.float32)
            obs[0:3] = omega_b * ANG_VEL_SCALE
            obs[3:6] = gravity_orientation(quat)
            obs[6:9] = cmd * CMD_SCALE
            obs[9:9 + NUM_ACT] = qj
            obs[9 + NUM_ACT:9 + 2 * NUM_ACT] = dqj
            obs[9 + 2 * NUM_ACT:9 + 3 * NUM_ACT] = action
            obs[45:47] = (np.sin(2 * np.pi * phase), np.cos(2 * np.pi * phase))

            with torch.no_grad():
                action = policy(torch.from_numpy(obs).unsqueeze(0)).numpy().squeeze()

            target = action * ACTION_SCALE + DEFAULT_LEG
            robot.apply_action(ArticulationAction(
                joint_positions=target, joint_indices=leg_idx))
            if len(arm_idx):
                robot.apply_action(ArticulationAction(
                    joint_positions=arm_val, joint_indices=arm_idx))

        render = i % CAPTURE_EVERY == 0
        world.step(render=render)
        if render:
            frame = np.asarray(cam.get_rgba())
            if frame.ndim == 3 and frame.shape[2] >= 3:
                writer.append_data(frame[:, :, :3])
                frames += 1
            if i % (CAPTURE_EVERY * 5) == 0:
                p, q = robot.get_world_pose()
                print(f"  t={i * PHYS_DT:5.1f}s  base=({p[0]:5.2f},{p[1]:5.2f},{p[2]:4.2f})"
                      f"  grav_z={gravity_orientation(q)[2]:+.2f}", flush=True)

        pos = robot.get_world_pose()[0]
        if pos[2] < 0.4:
            print(f"[fail] H1-2 fell at t={i * PHYS_DT:.1f}s", flush=True)
            break

    writer.close()
    end = robot.get_world_pose()[0]
    print(f"\n[result] base {np.round(end, 2)} (started {START_XY}), "
          f"{frames} frames -> out/{args.name}.mp4", flush=True)
    sim_app.close()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Unitree H1 walks across the ASTRA SWEETS scan, grips a cube off a table, carries it away.

  python h1_pick_demo.py --stage scene   # room + table + cube, two stills. Check placement.
  python h1_pick_demo.py --stage walk    # office + stock locomotion policy, no gripper.
  python h1_pick_demo.py --stage arm     # H1 parked at the table, reach + grip only.
  python h1_pick_demo.py --stage demo    # the whole thing -> out/demo.mp4

Headless only; workstation-1 has no display.
"""
import argparse
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- tunables --
# Room frame: scan's min corner at the origin, WALKABLE FLOOR at z=0, metres.
# The scan sits ~50 m from the origin, and its floor slab is 0.277 m thick -- the
# z term lands the slab's *top* on zero, not its underside, or everything placed
# in this file would sit 28 cm inside the floor.
OFFICE_USD = os.path.join(HERE, "assets", "office.usdc")
FLOOR_THICKNESS = 0.276737
OFFICE_SHIFT = (51.5357, -30.5250, 2.70648 - FLOOR_THICKNESS)
ROOM = (11.078, 7.974)   # room extent in the shifted frame, from the scan bbox

# Table position was picked by scanning the room for the spot with the most
# clearance to any scan geometry between 3 cm and 2 m above the floor. This one
# has 1.47 m; the obvious-looking mid-room spot had 0.74 m and visibly wedged the
# table between a kerb and a post.
# Bench and cube placement are NOT cosmetic -- they are set by the arm's measured
# reach envelope. H1's 4-DoF arm tops out around 0.50 m FORWARD of the torso, so a
# head-on grasp is unsolvable and the robot reaches at full stretch and topples.
# Standing head-on also puts its toes ~4 cm from the bench, and it kicks the bench
# over as it sways (this happens even with the arm frozen).
# Sideways is the arm's happy place: 0.22 m forward, 0.30 m to the RIGHT, is ~9 deg
# of joint travel from ARM_HOME. So the robot parks ALONGSIDE the bench, feet
# parallel to it, and reaches out sideways. Re-check arm_ik.reachable() if you move
# any of these.
TABLE_XY, TABLE_TOP, TABLE_HALF = (8.55, 1.40), 0.80, (0.45, 0.30)
CUBE_XY, CUBE_SIZE, CUBE_MASS = (8.37, 1.62), 0.08, 0.25

# The robot keeps to y~2.0 the whole way -- the one lane measured clear across the
# full width of the room, and the lane --stage walk already traversed upright.
# It stops beside the table and turns to face it rather than driving at it.
H1_START = (3.00, 2.00)
# Walk up the lane, then TURN AND FACE THE TABLE to pick -- the robot squares up to
# the bench rather than sidling along it. The note above says a head-on grasp is
# unsolvable; that was measured approaching along +x from 0.40 m out, where the cube
# sits at the very edge of the arm's forward envelope. Facing the bench across the
# lane instead (turn right, cube almost straight ahead at 0.38 m) is solvable, and
# arm_ik.reachable() puts pregrasp/grasp/lift all at 0.0 cm residual from here.
# Clearance to the bench footprint is 0.30 m, exactly what the old sideways stance
# had, so this is no closer to kicking it over. It does cost arm travel: 58.8 deg
# from ARM_HOME versus 12.0 deg sideways -- affordable only because the base is
# pinned through the pick. Re-run arm_ik.reachable() if you move any of this.
STAND_XY = (8.40, 1.90)          # on the walk lane, square to the bench
WORK_YAW = np.radians(-94.5)     # face -y, i.e. straight at the table
DROP_XY = (4.00, 2.00)   # carry it back the way it came
WALK_START, WALK_GOAL = (3.00, 2.00), (8.60, 2.00)

# Gripper: two fingers on prismatic joints straight onto the forearm, which runs
# +X from the elbow and ends at 0.27. No wrist on H1, so the fingers' closing
# direction is fixed by the arm pose -- they close along the forearm's Y.
GRIP_MOUNT_X = 0.255
# Jaw roll about the forearm axis. TRIED AND REJECTED at 13.7 deg (the measured jaw
# tilt at the grasp pose): the intent was face-parallel contact instead of pinching
# the cube's top edges, but it made the approach miss -- jaws closed to 0.030 on
# empty air and punted the cube 1.5 m. Left as a knob because edge contact is still
# the reason the grip only holds 2-3 s; it needs the grasp pose re-tuned alongside
# it, not a roll bolted onto the existing one.
GRIP_MOUNT_ROLL = 0.0
FINGER_LEN, FINGER_THK, FINGER_HT = 0.11, 0.016, 0.05
# Half-separation is measured between finger CENTRES, but the jaws grip with their
# inner faces, half a finger-thickness further in. Closing to CUBE_SIZE/2 therefore
# commands the faces ~8 mm INSIDE the cube on each side: the drive never reaches
# its target, keeps pushing, and squirts the cube out -- measured as a clean 0.22 m
# lift that slipped free two seconds later. Target the faces on the cube's surface
# with a couple of mm of interference for grip.
GRIP_OPEN = 0.070
# 6 mm of interference past the cube's face. Commanding the faces exactly ON the
# surface means the drive reaches its target and presses with ~0 N, so the cube just
# rests between the jaws and shakes loose on the lift.
# Measured, not derived. The jaws sit ~14 deg off horizontal so they pinch the
# cube's EDGES, not its flat faces, and reach equilibrium around a 0.114 m gap
# (half-separation 0.057) rather than the 0.096 the flat-face geometry predicts.
# Commanding far past that just grinds through and pops the cube out after a few
# seconds. Sit slightly inside the equilibrium for a steady squeeze.
GRIP_CLOSED = 0.0515
# Close the jaws at a finite speed. A step command with stiff drives is a ~40 N
# hammer blow that punts the cube out sideways before contact can settle; too soft
# a squeeze and it shakes loose on the lift. Ramp in, then hold.
GRIP_RATE = 0.05         # m/s
# Descend with the jaws WIDE. Caging to 0.11 m leaves only 8 mm either side of an
# 0.08 m cube, so any approach error clips its edge and drags it out of reach. The
# cage was worth it when the base was drifting; with the base pinned it just costs
# clearance.
GRIP_CAGE = GRIP_OPEN
# Squeeze force = KP * (commanded - actual), CAPPED at MAX_FORCE. Keep KP stiff so
# the jaws track their target briskly, but cap the force hard -- the cap, not the
# gain, is what decides whether the cube survives.
#
# Measured on arm_v29, the run that lifted 0.31 m and then dropped it:
#   t=6.0  fingA=[-0.0104, 0.0107] vs commanded -0.0185 -> 8.1 mm error -> 12.2 N. Held.
#   t=7.0  fingA=[-0.0184, 0.0186] -> 0.1 mm error -> 0.15 N. Jaws fully shut, cube gone.
#   armVmax=0.01 rad/s across that whole interval -- the ARM WAS NOT MOVING.
# So the cube was not shaken loose, and it did not slip: 12 N of squeeze extruded it,
# like a watermelon seed. The jaws sit ~14 deg off horizontal (a 4-DoF wristless arm
# cannot orient them) so they only ever touch the cube's EDGES, and edge contact under
# a force that large has nowhere to go but out.
#
# Raising friction or slowing the lift both push the wrong way -- friction is already
# 2.0/1.8, and the arm was stationary.
#
# KP and MAX_FORCE are NOT interchangeable knobs here, which cost a run to learn:
#   MAX_FORCE = the finger's authority to hold its commanded position
#   KP        = the squeeze it applies once the cube blocks it
# arm_v30 capped MAX_FORCE at 5 N and regressed badly: incidental contact during the
# descend knocked finger b to its 0.09 joint limit, and recovering 90 mm of error needs
# KP*0.09 = 135 N, so at a 5 N ceiling it stayed jammed there for the rest of the run.
# A stuck finger poisons grip_center() (the fingertip MIDPOINT moves ~45 mm), which
# feeds cart_bias, which drags the IK target onto a folded branch (elbow 134 deg vs
# 42 deg) -- descend then timed out and the shut jaws swatted the cube onto the floor.
#
# So: leave MAX_FORCE high enough to recover from a knock, and lower KP instead. At the
# measured 8.1 mm contact interference, KP=600 gives ~4.9 N of squeeze -- across two
# contacts at mu=1.8 that still holds ~17 N against a 2.45 N cube (7x margin) while
# being far too weak to extrude it, and 600*0.09 = 54 N of recovery authority remains.
GRIP_KP, GRIP_KD, GRIP_MAX_FORCE = 600.0, 50.0, 40.0
FINGER_MASS = 0.06
# The policy's own arm gains are tuned for a free-swinging arm, not for holding a
# commanded pose against gravity plus a gripper. Measured 8.5 deg of elbow droop at
# the grasp, which is ~4.5 cm of tool height -- exactly enough to close the jaws
# above the cube. We override these four joints anyway, so stiffen them.
ARM_KP, ARM_KD = 1200.0, 35.0
TOOL = (GRIP_MOUNT_X + FINGER_LEN * 0.55, 0.0, 0.0)     # IK target point on the forearm

ARM_HOME = np.array([0.28, 0.0, 0.0, 0.52])   # policy's default right-arm pose
# ARM_CARRY as a hand-picked joint pose was a trap: [0.55,-0.25,0,1.45] puts the
# tool at torso (-0.29,-0.34,-0.12), i.e. DOWN and BEHIND the robot, so "lift"
# quietly pushed the cube into the bench. The lift is Cartesian now -- straight up
# from wherever the cube was grasped, which arm_ik confirms is reachable to +0.30 m.
LIFT_UP = 0.15
# Max joint-target speed for the arm. Snapping straight to an IK solution makes the
# position drives slam the arm across in one tick, and the reaction torque tips the
# robot over -- it is balancing on two feet, not bolted to a bench.
ARM_RATE = 1.2                                # rad/s; fast lifts shake the cube free
PREGRASP_UP = 0.20       # swing in this high so the jaws clear the cube

GRIP_JOINTS = ("right_gripper_a_joint", "right_gripper_b_joint")

# ------------------------------------------------------------ surface grip ---
# WHY THIS EXISTS. Three runs proved the friction grasp has no stable operating
# point on this robot, and the reason is structural, not a bad gain:
#   arm_v29  KP=1500 F=40  ->  12.2 N squeeze, cube EXTRUDED after a 0.31 m lift
#   arm_v30  KP=1500 F=5   ->  finger jammed at its joint limit, cube swatted off
#   arm_v31  KP=600  F=40  ->  ~0 N squeeze at the lift, cube slipped free
# H1's arm is 4-DoF with no wrist, so the jaws cannot be rotated flat against the
# cube -- they meet it at ~14 deg and only ever touch its EDGES. Edge contact has
# no squeeze window: too little and it slips, too much and it extrudes.
#
# isaacsim.robot.surface_gripper is NVIDIA's own answer to exactly this, and an
# Isaac Lab maintainer recommends it over friction grasping for grasp-like tasks
# (see RESEARCH.md). It spawns a D6 joint between the gripper body and whatever
# rigid body is within gripThreshold, so it does not care about jaw orientation.
#
# What stays real: gravity on the cube (disable_gravity=False -- the cube has
# weight the whole time), the arm's torques, every contact in the scene, and the
# walking either side of the pick. What is simulated away: the friction pinch
# itself. The attach is force-limited, not a weld -- exceed SURF_FORCE_LIMIT and
# it lets go, so a bad grasp still drops the cube.
# ponytail: attach-on-contact instead of a friction pinch; the real fix is a
# wristed arm (h1_with_hand.usd adds one roll DoF, still not enough) or a hand,
# which is an asset change, not a tuning job.
# The grip point must sit where the CUBE will be, and its threshold must be too
# short to touch our own jaws -- at translate=GRIP_MOUNT_X with threshold 0.10 it
# grabbed its own finger during the raise (surf=Y with nothing commanded, gap
# collapsing 0.140 -> 0.078), and a stuck finger poisons grip_center() -> cart_bias
# -> the descend IK, which then froze 0.32 m short of the cube.
# Fingers sit at +/-GRIP_OPEN with their inner faces half a thickness in, i.e. at
# 0.070 - 0.008 = 0.062 m laterally. Stay under that with margin.
SURF_TRANSLATE = TOOL[0]               # the tool point, i.e. between the fingertips
SURF_THRESHOLD = 0.05                  # < 0.062, so it can never catch a jaw
SURF_FORCE_LIMIT = 200.0                # N -- 20x the cube's 2.45 N weight, finite
SURF_TORQUE_LIMIT = 25.0                # N.m
SURF_KP, SURF_KD = 1.0e5, 1.0e4        # stiff enough that the cube does not sag

# THE joint order the pretrained policy expects: H1's articulation order BEFORE the
# fingers exist. Adding two DoF does not append them -- PhysX renumbers the whole
# articulation (torso 2->0, left_hip_yaw 0->3, left_elbow 17->13, left_ankle 15->19),
# so "dof_names minus the fingers" is NOT the training order and cannot be derived
# at runtime. Feed the policy the wrong order and it reads hips as torso, commands
# legs onto the wrong joints, and the robot falls over inside half a second.
POLICY_JOINTS = (
    "left_hip_yaw_joint", "right_hip_yaw_joint", "torso_joint",
    "left_hip_roll_joint", "right_hip_roll_joint",
    "left_shoulder_pitch_joint", "right_shoulder_pitch_joint",
    "left_hip_pitch_joint", "right_hip_pitch_joint",
    "left_shoulder_roll_joint", "right_shoulder_roll_joint",
    "left_knee_joint", "right_knee_joint",
    "left_shoulder_yaw_joint", "right_shoulder_yaw_joint",
    "left_ankle_joint", "right_ankle_joint",
    "left_elbow_joint", "right_elbow_joint",
)
ARM_JOINTS = (
    "right_shoulder_pitch_joint", "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint", "right_elbow_joint",
)

PHYS_DT = 1.0 / 200.0
CAPTURE_EVERY = 8        # -> 25 fps video
IK_EVERY = 5             # re-solve the arm at 40 Hz while closing in

# Camera lives in the far corner of the room looking back down the work aisle,
# which frames the table and the whole walk path.
CAM_EYE, CAM_LOOK = (0.90, 6.50, 2.95), (6.20, 1.40, 0.85)

# --------------------------------------------------------------- boot kit ---
parser = argparse.ArgumentParser()
parser.add_argument("--stage", choices=("scene", "walk", "arm", "demo"), default="demo")
parser.add_argument("--out", default=os.path.join(HERE, "out"))
parser.add_argument("--seconds", type=float, default=42.0)
parser.add_argument("--res", type=int, nargs=2, default=(1280, 720))
parser.add_argument("--freeze-arm", action="store_true",
                    help="hold the arm at ARM_HOME; isolates balance from arm motion")
parser.add_argument("--no-gripper", action="store_true",
                    help="skip the fingers entirely; isolates balance from the gripper")
parser.add_argument("--name", default=None,
                    help="basename for the video (default: the stage name)")
parser.add_argument("--glue", action="store_true",
                    help="demo only: make the latched attach unbreakable")
args = parser.parse_args()
if args.glue:
    SURF_FORCE_LIMIT = 1.0e6
    SURF_TORQUE_LIMIT = 1.0e6

from isaacsim import SimulationApp  # noqa: E402

sim_app = SimulationApp({"headless": True})

import omni.usd  # noqa: E402
from isaacsim.core.api import World  # noqa: E402
from isaacsim.core.api.objects import DynamicCuboid, FixedCuboid, GroundPlane  # noqa: E402
from isaacsim.core.api.materials import PhysicsMaterial  # noqa: E402
from isaacsim.core.prims import SingleXFormPrim  # noqa: E402
from isaacsim.core.utils.stage import add_reference_to_stage  # noqa: E402
from isaacsim.core.utils.types import ArticulationAction  # noqa: E402
from isaacsim.robot.policy.examples.robots.h1 import H1FlatTerrainPolicy  # noqa: E402
from isaacsim.robot.surface_gripper import SurfaceGripper  # noqa: E402
from isaacsim.robot.policy.examples.controllers.config_loader import (  # noqa: E402
    get_robot_joint_properties,
)
from isaacsim.sensors.camera import Camera  # noqa: E402
from pxr import Gf, Sdf, Usd, UsdGeom, UsdPhysics, UsdShade  # noqa: E402

import arm_ik  # noqa: E402


# ------------------------------------------------------------------ utils ---
def quat_look_at(eye, target):
    """USD cameras look down their local -Z with +Y up. Returns wxyz."""
    eye, target = np.asarray(eye, float), np.asarray(target, float)
    fwd = eye - target                      # camera +Z points back at the eye
    fwd /= np.linalg.norm(fwd)
    right = np.cross([0.0, 0.0, 1.0], fwd)
    n = np.linalg.norm(right)
    right = np.array([1.0, 0.0, 0.0]) if n < 1e-6 else right / n
    up = np.cross(fwd, right)
    R = np.column_stack([right, up, fwd])
    t = np.trace(R)
    if t > 0:
        s = 0.5 / np.sqrt(t + 1.0)
        q = np.array([0.25 / s, (R[2, 1] - R[1, 2]) * s, (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s])
    else:
        i = int(np.argmax(np.diag(R)))
        j, k = (i + 1) % 3, (i + 2) % 3
        s = 2.0 * np.sqrt(1.0 + R[i, i] - R[j, j] - R[k, k])
        q = np.zeros(4)
        q[0] = (R[k, j] - R[j, k]) / s
        q[i + 1] = 0.25 * s
        q[j + 1] = (R[j, i] + R[i, j]) / s
        q[k + 1] = (R[k, i] + R[i, k]) / s
    return q / np.linalg.norm(q)


def R_to_quat(R):
    """Rotation matrix -> wxyz quaternion."""
    t = np.trace(R)
    if t > 0:
        s = 0.5 / np.sqrt(t + 1.0)
        return np.array([0.25 / s, (R[2, 1] - R[1, 2]) * s,
                         (R[0, 2] - R[2, 0]) * s, (R[1, 0] - R[0, 1]) * s])
    i = int(np.argmax(np.diag(R)))
    j, k = (i + 1) % 3, (i + 2) % 3
    s = 2.0 * np.sqrt(1.0 + R[i, i] - R[j, j] - R[k, k])
    q = np.zeros(4)
    q[0] = (R[k, j] - R[j, k]) / s
    q[i + 1] = 0.25 * s
    q[j + 1] = (R[j, i] + R[i, j]) / s
    q[k + 1] = (R[k, i] + R[i, k]) / s
    return q / np.linalg.norm(q)


def quat_to_R(q):
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def yaw_of(q):
    R = quat_to_R(q)
    return float(np.arctan2(R[1, 0], R[0, 0]))


def wrap(a):
    return (a + np.pi) % (2.0 * np.pi) - np.pi


# ------------------------------------------------------------------ scene ---
def add_office(stage):
    """Reference the scan and make every mesh a static triangle-mesh collider."""
    add_reference_to_stage(usd_path=OFFICE_USD, prim_path="/World/Office")
    SingleXFormPrim("/World/Office").set_world_pose(position=np.array(OFFICE_SHIFT))
    n = 0
    for prim in Usd.PrimRange(stage.GetPrimAtPath("/World/Office")):
        if prim.IsA(UsdGeom.Mesh):
            UsdPhysics.CollisionAPI.Apply(prim)
            # exact triangles: legal here because the scan never moves
            UsdPhysics.MeshCollisionAPI.Apply(prim).CreateApproximationAttr("none")
            n += 1
    print(f"[scene] office: {n} static colliders, floor at z=0", flush=True)


def add_gripper(stage, grip_mat):
    """Two prismatic fingers bolted to the right forearm.

    Authored to mirror h1.usd exactly: link prims are siblings under the
    articulation root, and the joint lives under its parent link. That is what
    makes PhysX fold them into H1's articulation instead of leaving them loose.
    """
    elbow = "/World/H1/right_elbow_link"
    # Place the fingers on the forearm as it sits in ARM_HOME -- the stance the
    # robot actually starts in. Authoring them at the USD zero pose instead leaves
    # them a good 20 cm off the forearm, and on the first physics tick the
    # prismatic joints yank them into place hard enough to knock the robot over.
    elbow_p, elbow_R = arm_ik.fk(ARM_HOME)
    c, sr = np.cos(GRIP_MOUNT_ROLL), np.sin(GRIP_MOUNT_ROLL)
    roll = np.array([[1, 0, 0], [0, c, -sr], [0, sr, c]])
    elbow_quat = R_to_quat(elbow_R @ roll)
    for name, sign in zip(GRIP_JOINTS, (+1.0, -1.0)):
        body = f"/World/H1/{name.replace('_joint', '')}"
        xf = UsdGeom.Xform.Define(stage, body)
        offset = np.array([GRIP_MOUNT_X, 0.0, 0.0]) + roll @ np.array([0.0, sign * GRIP_OPEN, 0.0])
        pos = elbow_p + elbow_R @ offset
        xf.AddTranslateOp().Set(Gf.Vec3d(*[float(v) for v in pos]))
        xf.AddOrientOp().Set(Gf.Quatf(float(elbow_quat[0]), Gf.Vec3f(
            float(elbow_quat[1]), float(elbow_quat[2]), float(elbow_quat[3]))))
        prim = xf.GetPrim()
        UsdPhysics.RigidBodyAPI.Apply(prim)
        UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(FINGER_MASS)

        geom = UsdGeom.Cube.Define(stage, body + "/geom")
        geom.GetSizeAttr().Set(2.0)                       # unit cube spans -1..1
        geom.AddTranslateOp().Set(Gf.Vec3d(FINGER_LEN / 2, 0.0, 0.0))
        geom.AddScaleOp().Set(Gf.Vec3f(FINGER_LEN / 2, FINGER_THK / 2, FINGER_HT / 2))
        UsdPhysics.CollisionAPI.Apply(geom.GetPrim())
        UsdPhysics.MeshCollisionAPI.Apply(geom.GetPrim()).CreateApproximationAttr("convexHull")
        # PhysicsMaterial has no .apply(); binding to a raw prim goes through
        # MaterialBindingAPI with the "physics" purpose. The friction here is what
        # stops the cube squirting out from between the fingers.
        UsdShade.MaterialBindingAPI(geom.GetPrim()).Bind(
            grip_mat.material, UsdShade.Tokens.weakerThanDescendants, "physics")

        joint = UsdPhysics.PrismaticJoint.Define(stage, f"{elbow}/{name}")
        joint.CreateBody0Rel().SetTargets([elbow])
        joint.CreateBody1Rel().SetTargets([body])
        joint.CreateAxisAttr("Y")
        joint.CreateLocalPos0Attr(Gf.Vec3f(*[float(v) for v in offset]))
        joint.CreateLocalRot0Attr(Gf.Quatf(float(np.cos(GRIP_MOUNT_ROLL / 2)),
                                           Gf.Vec3f(float(np.sin(GRIP_MOUNT_ROLL / 2)), 0.0, 0.0)))
        joint.CreateLocalPos1Attr(Gf.Vec3f(0.0, 0.0, 0.0))
        joint.CreateLowerLimitAttr(-0.09)
        joint.CreateUpperLimitAttr(0.09)
        # Holding a 0.35 kg cube at mu=1.2 needs about 1.4 N of squeeze. Stiff
        # drives here (4000 N/m) put hundreds of newtons through a 0.12 kg finger
        # hanging off the forearm and shove the whole robot over -- with the
        # gripper removed the same stance is rock steady for 14 s.
        drive = UsdPhysics.DriveAPI.Apply(joint.GetPrim(), "linear")
        drive.CreateTypeAttr("force")
        drive.CreateMaxForceAttr(GRIP_MAX_FORCE)
        drive.CreateStiffnessAttr(GRIP_KP)
        drive.CreateDampingAttr(GRIP_KD)
        drive.CreateTargetPositionAttr(0.0)
    print("[scene] gripper: 2 prismatic fingers on right_elbow_link")


def build(world):
    stage = omni.usd.get_context().get_stage()
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.z)

    grip_mat = PhysicsMaterial(
        "/World/Looks/grip", static_friction=2.0, dynamic_friction=1.8, restitution=0.0)

    # Backstop only, well below the scan's slab, and hidden: the robot walks on
    # the scanned floor. A visible plane level with it would z-fight.
    ground = GroundPlane("/World/ground", z_position=-1.0)
    UsdGeom.Imageable(ground.prim).MakeInvisible()
    # the scan's own light and camera sit outside the room at the CAD origin, so
    # they are useless -- light the place ourselves
    sky = stage.DefinePrim("/World/sky", "DomeLight")
    sky.CreateAttribute("inputs:intensity", Sdf.ValueTypeNames.Float).Set(500.0)

    add_office(stage)

    table = FixedCuboid(
        "/World/table", position=np.array([*TABLE_XY, TABLE_TOP / 2]),
        scale=np.array([TABLE_HALF[0] * 2, TABLE_HALF[1] * 2, TABLE_TOP]),
        color=np.array([0.45, 0.33, 0.22]))
    table.apply_physics_material(grip_mat)

    cube = world.scene.add(DynamicCuboid(
        "/World/cube", name="cube",
        position=np.array([*CUBE_XY, TABLE_TOP + CUBE_SIZE / 2 + 0.001]),
        scale=np.array([CUBE_SIZE] * 3), mass=CUBE_MASS,
        color=np.array([0.9, 0.25, 0.15])))
    cube.apply_physics_material(grip_mat)
    return cube, grip_mat


# ------------------------------------------------------------------ robot ---
class H1WithGripper(H1FlatTerrainPolicy):
    """H1 whose articulation gained two finger DoFs.

    The pretrained policy only knows the original 19 joints, so every read and
    write it does is confined to those indices. Without this the gains array
    comes back short of the DoF count and the observation silently misaligns.
    """

    def initialize(self):
        self.robot.initialize()
        self.robot.get_articulation_controller().set_effort_modes("force")
        self.robot.get_articulation_controller().switch_control_mode("position")

        names = list(self.robot.dof_names)
        loco_names = list(POLICY_JOINTS)     # training order, NOT articulation order
        missing = [n for n in loco_names + list(GRIP_JOINTS) if n not in names]
        assert not missing, f"joints missing from articulation: {missing}"
        assert len(names) == len(loco_names) + len(GRIP_JOINTS), \
            f"expected {len(loco_names) + len(GRIP_JOINTS)} dofs, articulation has {len(names)}"
        self.loco_idx = np.array([names.index(n) for n in loco_names])
        self.grip_idx = np.array([names.index(n) for n in GRIP_JOINTS])
        self.arm_idx = np.array([names.index(n) for n in ARM_JOINTS])
        self.arm_in_loco = np.array([loco_names.index(n) for n in ARM_JOINTS])

        eff, vel, kp, kd, dpos, dvel = get_robot_joint_properties(self.policy_env_params, loco_names)
        view = self.robot._articulation_view
        view.set_gains(np.array([kp]), np.array([kd]), joint_indices=self.loco_idx)
        view.set_max_efforts(np.array([eff]), joint_indices=self.loco_idx)
        view.set_max_joint_velocities(np.array([vel]), joint_indices=self.loco_idx)
        # fingers: stiff position drives, they are not part of the policy
        view.set_gains(np.array([[GRIP_KP, GRIP_KP]]), np.array([[GRIP_KD, GRIP_KD]]),
                       joint_indices=self.grip_idx)
        view.set_max_efforts(np.array([[GRIP_MAX_FORCE, GRIP_MAX_FORCE]]),
                             joint_indices=self.grip_idx)
        view.set_gains(np.array([[ARM_KP] * 4]), np.array([[ARM_KD] * 4]),
                       joint_indices=self.arm_idx)
        self.default_pos = np.array(dpos)
        self.default_vel = np.array(dvel)
        # stock H1FlatTerrainPolicy deliberately skips _set_articulation_props()
        # and keeps the USD's own root properties -- match that
        # At ARM_HOME the fingers land at torso-local (0.12,-0.16,-0.07), i.e.
        # inside the robot's own right hip. With self-collision on, PhysX shoves
        # the robot sideways off its feet before the demo even starts -- the same
        # stance is rock steady with --no-gripper.
        self.robot.set_enabled_self_collisions(False)
        self._torso = SingleXFormPrim("/World/H1/torso_link")
        self._fingers = [SingleXFormPrim(f"/World/H1/{n.replace('_joint', '')}")
                         for n in GRIP_JOINTS]
        print(f"[robot] {len(names)} dofs, {len(loco_names)} driven by policy, "
              f"fingers at {self.grip_idx.tolist()}", flush=True)
        print("[dofs] " + " ".join(f"{i}:{n}" for i, n in enumerate(names)), flush=True)
        print("[loco] " + " ".join(loco_names), flush=True)

    def _compute_observation(self, command):
        from isaacsim.core.utils.rotations import quat_to_rot_matrix
        lin_I = self.robot.get_linear_velocity()
        ang_I = self.robot.get_angular_velocity()
        _, q_IB = self.robot.get_world_pose()
        R_BI = quat_to_rot_matrix(q_IB).transpose()

        obs = np.zeros(69)
        obs[:3] = R_BI @ lin_I
        obs[3:6] = R_BI @ ang_I
        obs[6:9] = R_BI @ np.array([0.0, 0.0, -1.0])
        obs[9:12] = command
        obs[12:31] = self.robot.get_joint_positions()[self.loco_idx] - self.default_pos
        obs[31:50] = self.robot.get_joint_velocities()[self.loco_idx]
        obs[50:69] = self._previous_action
        return obs

    def forward(self, dt, command, arm_q=None, grip=None):
        if self._policy_counter % self._decimation == 0:
            self.action = self._compute_action(self._compute_observation(command))
            self._previous_action = self.action.copy()
        target = self.default_pos + self.action * self._action_scale
        if arm_q is not None:
            target[self.arm_in_loco] = arm_q          # scripted arm beats the policy
        self.robot.apply_action(ArticulationAction(
            joint_positions=target, joint_indices=self.loco_idx))
        if grip is not None:
            # Each finger sits at +/-GRIP_OPEN at joint zero, so a target is the
            # *displacement* from open. Commanding the half-gap directly drives
            # them further apart -- i.e. opens when you meant to close.
            d = grip - GRIP_OPEN
            self.robot.apply_action(ArticulationAction(
                joint_positions=np.array([d, -d]), joint_indices=self.grip_idx))
        self._policy_counter += 1

    def torso_frame(self):
        pos, quat = self._torso.get_world_pose()
        return np.asarray(pos, float), quat_to_R(np.asarray(quat, float))

    def grip_center(self):
        """World midpoint between the two fingertips."""
        pts = []
        for f in self._fingers:
            p, q = f.get_world_pose()
            pts.append(np.asarray(p, float)
                       + quat_to_R(np.asarray(q, float)) @ np.array([FINGER_LEN * 0.55, 0.0, 0.0]))
        return sum(pts) / len(pts), float(np.linalg.norm(pts[0] - pts[1]))

    def solve_arm(self, world_target, q_prev=None):
        """World point -> right-arm joint angles, via the torso frame.

        Warm-started from the last solution: an 8-seed search costs ~12k FK
        evaluations, which is not something to do at 200 Hz. Callers should also
        throttle -- see IK_EVERY.
        """
        p, R = self.torso_frame()
        local = R.T @ (np.asarray(world_target, float) - p)
        if q_prev is not None:
            q, err = arm_ik.ik(local, q_prev, TOOL, iters=60)
            if err < 0.01:
                return True, q, err
        return arm_ik.reachable(local, TOOL, prefer=ARM_HOME)


def hold_heading(yaw, goal_yaw):
    """Yaw-only correction while manipulating.

    Reaching sideways with the right arm puts a yaw moment into the robot and it
    pivots -- measured 105 degrees of spin during a single reach, which walks the
    hand right off the cube. Yaw rate is the one command this locomotion policy
    tracks well standing still.

    Do NOT add vx/vy here. Commanding translation made it wander 2.5 m from its
    station, versus 0.37 m when simply left alone.
    """
    err = wrap(goal_yaw - yaw)
    if abs(err) < 0.05:
        return np.zeros(3)
    return np.array([0.0, 0.0, float(np.clip(1.2 * err, -0.4, 0.4))])
    d = np.asarray(goal_xy, float) - np.asarray(base_xy, float)
    if np.linalg.norm(d) < 0.10:
        d[:] = 0.0            # deadband: nagging it every tick makes it stumble
    c, s_ = np.cos(-yaw), np.sin(-yaw)
    body = np.array([c * d[0] - s_ * d[1], s_ * d[0] + c * d[1]])
    yerr = wrap(goal_yaw - yaw)
    return np.array([float(np.clip(0.5 * body[0], -0.15, 0.15)),
                     float(np.clip(0.5 * body[1], -0.15, 0.15)),
                     float(np.clip(1.0 * yerr, -0.25, 0.25)) if abs(yerr) > 0.08 else 0.0])


def drive_to(pose_xy, yaw, goal_xy, stop_at):
    """Waypoint follower -> (vx, vy, wz). Turn first, then walk."""
    d = np.asarray(goal_xy, float) - np.asarray(pose_xy, float)
    dist = float(np.linalg.norm(d))
    if dist <= stop_at:
        return np.zeros(3), True
    head_err = wrap(np.arctan2(d[1], d[0]) - yaw)
    wz = float(np.clip(2.0 * head_err, -0.8, 0.8))
    vx = 0.0 if abs(head_err) > 0.6 else float(np.clip(0.9 * (dist - stop_at), 0.0, 0.8))
    return np.array([vx, 0.0, wz]), False


# ------------------------------------------------------------------- main ---
def main():
    use_grip = args.stage in ("arm", "demo") and not args.no_gripper
    os.makedirs(args.out, exist_ok=True)
    world = World(stage_units_in_meters=1.0, physics_dt=PHYS_DT, rendering_dt=PHYS_DT * 4)
    cube, grip_mat = build(world)

    h1 = None
    if args.stage != "scene":
        start, orient = np.array([*H1_START, 1.05]), None
        if args.stage == "arm":
            # park it where the approach leaves it: alongside the bench, facing +x
            start = np.array([*STAND_XY, 1.05])
            orient = np.array([np.cos(WORK_YAW / 2), 0.0, 0.0, np.sin(WORK_YAW / 2)])
        elif args.stage == "walk":
            start = np.array([*WALK_START, 1.05])
        # walk runs the stock 19-DoF policy untouched -- no gripper, no subclass,
        # so a failure there is the scene or the policy, never our joint plumbing
        cls = H1WithGripper if use_grip else H1FlatTerrainPolicy
        h1 = cls(prim_path="/World/H1", name="h1", position=start, orientation=orient)
        if use_grip:
            add_gripper(omni.usd.get_context().get_stage(), grip_mat)

    cam = Camera("/World/cam", resolution=tuple(args.res))
    world.reset()
    cam.initialize()
    # Stock intrinsics give a 23.7-degree FOV -- far too tight for a room; the
    # robot ends up a speck at the frame edge. Widen to ~65 degrees.
    cam.set_horizontal_aperture(2.0 * cam.get_focal_length() * np.tan(np.radians(65.0) / 2))
    if h1 is not None:
        h1.initialize()
        h1.post_reset()
        # Start in the policy's own default stance. Its observation feeds
        # (joint_pos - default_pos) to the network, so spawning at the USD's
        # straight-legged defaults hands it a huge error on step one and it
        # thrashes itself over. Crouched stance also matches the 1.05 m spawn.
        if not use_grip:
            print("[dofs] " + " ".join(f"{i}:{n}" for i, n in enumerate(h1.robot.dof_names)), flush=True)
        loco = getattr(h1, "loco_idx", None)
        h1.robot.set_joint_positions(h1.default_pos, joint_indices=loco)
        h1.robot.set_joint_velocities(np.zeros_like(h1.default_pos), joint_indices=loco)
        print(f"[robot] stance set, pelvis z={h1.robot.get_world_pose()[0][2]:.3f}", flush=True)

    # Surface gripper on the forearm. Created AFTER world.reset() -- Surface_Gripper
    # needs a live physics scene, and creating its D6 joint post-play keeps it a
    # plain maximal-coordinate joint instead of something PhysX folds into the
    # articulation and renumbers the DoFs with (see the joint-order note above).
    sg = None
    if use_grip:
        sg = SurfaceGripper(
            translate=SURF_TRANSLATE, direction="x", grip_threshold=SURF_THRESHOLD,
            force_limit=SURF_FORCE_LIMIT, torque_limit=SURF_TORQUE_LIMIT,
            bend_angle=np.pi / 24, kp=SURF_KP, kd=SURF_KD, disable_gravity=False)
        sg.initialize("/World/H1/right_elbow_link")
        n_after = len(h1.robot.dof_names)
        assert n_after == len(POLICY_JOINTS) + len(GRIP_JOINTS), \
            f"surface gripper changed the articulation: {n_after} dofs"
        print(f"[grip] surface gripper on right_elbow_link, +{SURF_TRANSLATE} m along x, "
              f"threshold {SURF_THRESHOLD} m, limits {SURF_FORCE_LIMIT} N / "
              f"{SURF_TORQUE_LIMIT} N.m, dofs still {n_after}", flush=True)

    # Must sit INSIDE the room (x 0-11.08, y 0-7.97, z 0-3.41) -- a camera parked
    # outside the shell just renders the back of a wall.
    eye, look = CAM_EYE, CAM_LOOK
    cam.set_world_pose(np.array(eye), quat_look_at(eye, look), camera_axes="usd")

    if args.stage == "scene":
        # Calibrate the render: markers on the room's four corners plus the
        # measured bounds, so placement is read off known points instead of
        # guessed from pixels.
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_])
        rng = cache.ComputeWorldBound(
            omni.usd.get_context().get_stage().GetPrimAtPath("/World/Office")).ComputeAlignedRange()
        lo, hi = rng.GetMin(), rng.GetMax()
        print(f"[scene] office world bounds {tuple(round(v,3) for v in lo)} .. "
              f"{tuple(round(v,3) for v in hi)}", flush=True)
        for i, (mx, my) in enumerate([(0, 0), (ROOM[0], 0), (0, ROOM[1]), ROOM]):
            FixedCuboid(f"/World/mark{i}", position=np.array([mx, my, 0.25]),
                        scale=np.array([0.5, 0.5, 0.5]), color=np.array([0.1, 0.35, 1.0]))
        # H1 spawn marker, so the top view shows where it starts
        FixedCuboid("/World/markspawn", position=np.array([*WALK_START, 0.25]),
                    scale=np.array([0.45, 0.45, 0.5]), color=np.array([0.1, 0.9, 0.3]))
        print(f"[scene] table at {TABLE_XY} top z={TABLE_TOP}, cube at "
              f"{np.asarray(cube.get_world_pose()[0]).round(3)}", flush=True)
        for _ in range(120):
            world.step(render=True)
        import imageio.v3 as iio
        # Derive the top-down height from the camera's OWN intrinsics rather than
        # an assumed FOV -- guessing it put the whole room out of frame.
        f_len, h_ap = cam.get_focal_length(), cam.get_horizontal_aperture()
        hfov = 2.0 * np.arctan(h_ap / (2.0 * f_len))
        top_h = (max(ROOM) * 0.62) / np.tan(hfov / 2.0)
        print(f"[scene] camera f={f_len:.3f} aperture={h_ap:.3f} hfov={np.degrees(hfov):.1f}deg "
              f"-> top view at {top_h:.1f} m", flush=True)
        for tag, e, l in (("scene_persp", CAM_EYE, CAM_LOOK),
                          ("scene_table", (7.0, 3.1, 1.7), (TABLE_XY[0], TABLE_XY[1], 0.80)),
                          ("scene_top", (ROOM[0] / 2, ROOM[1] / 2, top_h),
                           (ROOM[0] / 2, ROOM[1] / 2, 0.0))):
            cam.set_world_pose(np.array(e), quat_look_at(e, l), camera_axes="usd")
            for _ in range(6):
                world.step(render=True)
            iio.imwrite(os.path.join(args.out, f"{tag}.png"), cam.get_rgba()[:, :, :3])
            print(f"[scene] wrote {tag}.png")
        sim_app.close()
        return

    import imageio
    writer = imageio.get_writer(
        os.path.join(args.out, f"{args.name or args.stage}.mp4"),
        fps=int(1 / (PHYS_DT * CAPTURE_EVERY)))

    # get_rgba() hands back an empty 1-D array until the render product is live,
    # so let it spin up before anything tries to index a frame
    for _ in range(30):
        world.step(render=True)
    print(f"[cam] first frame {np.asarray(cam.get_rgba()).shape}", flush=True)

    print(f"[cfg] grip kp/kd/max={GRIP_KP}/{GRIP_KD}/{GRIP_MAX_FORCE} finger_mass={FINGER_MASS} "
          f"arm_rate={ARM_RATE} use_grip={use_grip} freeze={args.freeze_arm}", flush=True)
    cube_start = np.asarray(cube.get_world_pose()[0], float)
    phase = "raise" if args.stage == "arm" else "settle"
    t_phase = 0.0
    arm_q, arm_goal = ARM_HOME.copy(), ARM_HOME.copy()
    grip = grip_goal = GRIP_OPEN
    prev_half, stall_t = None, 0.0   # jaw-stall detector, see the close phase
    grasp_z = None
    grasp_pt = None
    log = []
    frames = 0

    pin = None                # base pose held during the pick, see PIN note below
    gc = np.full(3, np.inf)   # fingertip midpoint; stays inf when there is no gripper
    # Cartesian bias: closes the loop on where the fingertips ACTUALLY are. The arm
    # settles a few cm above its commanded pose (residual droop under its own weight
    # plus the gripper), which is what makes the jaws catch the cube's top edge and
    # roll it out during the lift. Servo the command until the tips land on target.
    cart_bias = np.zeros(3)
    grip_d = lambda pt: float(np.linalg.norm(gc - np.asarray(pt, float)))

    def servo_arm(goal_pt, goal_q, bias):
        """Bias-corrected IK, with a fallback when the bias leaves the envelope.

        cart_bias is an integrator and nothing bounded it against REACHABILITY. From
        the facing-the-table stance the arm has no envelope margin left, so the
        biased target fell outside it, solve_arm returned ok=False on every retry,
        and arm_goal froze -- the hand parked 0.31 m from the cube for the whole run
        while tracking its (stale) command perfectly. Drop the bias and retry bare
        rather than holding a pose that is going nowhere.
        """
        bias = np.clip(bias + 0.3 * (goal_pt - gc), -0.08, 0.08)
        ok, q, _ = h1.solve_arm(goal_pt + bias, goal_q)
        if not ok:
            bias = np.zeros(3)
            ok, q, _ = h1.solve_arm(goal_pt, goal_q)
        return (q if ok else goal_q), bias
    steps = int(args.seconds / PHYS_DT)
    for i in range(steps):
        render = i % CAPTURE_EVERY == 0
        base_p, base_q = h1.robot.get_world_pose()
        yaw = yaw_of(np.asarray(base_q, float))
        cube_p = np.asarray(cube.get_world_pose()[0], float)
        cmd = np.zeros(3)
        if use_grip and i % 4 == 0:
            gc = h1.grip_center()[0]          # fingertip midpoint, refreshed at 50 Hz
        # Grab the pin pose the first tick we are manipulating. Capturing it on the
        # face->reach edge misses --stage arm entirely, which starts in 'reach'.
        if use_grip and pin is None and phase in ("raise", "reach", "descend", "close", "lift"):
            # Snap to the DESIGNED stand pose, not wherever it drifted to. Every
            # grasp target is reachable from (8.15, 2.00) facing +x; from 7 cm
            # further out the descend target falls outside the arm's envelope and
            # the hand stalls above the cube. The snap is a few cm and invisible.
            pin = (np.array([STAND_XY[0], STAND_XY[1], base_p[2]], float),
                   np.array([np.cos(WORK_YAW / 2), 0.0, 0.0, np.sin(WORK_YAW / 2)], float))

        if phase == "settle":
            if t_phase > 1.5:
                phase, t_phase = ("route" if args.stage == "walk" else "approach"), 0.0
        elif phase == "route":
            cmd, done = drive_to(base_p[:2], yaw, WALK_GOAL, 0.30)
            if done:
                phase, t_phase = "hold", 0.0
        elif phase == "approach":
            cmd, done = drive_to(base_p[:2], yaw, STAND_XY, 0.12)
            if done:
                phase, t_phase = "face", 0.0
        elif phase == "face":
            # square up along the bench (+x), not toward it -- the reach is sideways
            err = wrap(WORK_YAW - yaw)
            cmd = np.array([0.0, 0.0, float(np.clip(1.5 * err, -0.6, 0.6))])
            if abs(err) < 0.10 and t_phase > 1.0:
                phase, t_phase = "raise", 0.0
        elif phase == "raise":
            cmd = hold_heading(yaw, WORK_YAW)
            # Straight up first. At ARM_HOME the hand sits at bench height, so
            # swinging sideways to the pregrasp drags it through the cube and
            # knocks it out of reach before the grasp ever starts.
            if use_grip and i % IK_EVERY == 0:
                up = np.array([gc[0], gc[1], cube_p[2] + PREGRASP_UP])
                arm_goal, cart_bias = servo_arm(up, arm_goal, cart_bias)
            if abs(gc[2] - (cube_p[2] + PREGRASP_UP)) < 0.07 or t_phase > 4.0:
                phase, t_phase = "reach", 0.0
        elif phase == "reach":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0:
                goal_pt = cube_p + np.array([0.0, 0.0, PREGRASP_UP])
                arm_goal, cart_bias = servo_arm(goal_pt, arm_goal, cart_bias)
            # Fire on the gripper actually arriving, not on a stopwatch. The base
            # drifts forward even with a zero command, so a fixed-duration reach
            # lets the robot wander off before the hand ever closes.
            if grip_d(cube_p + np.array([0.0, 0.0, PREGRASP_UP])) < 0.06 or t_phase > 6.0:
                phase, t_phase = "descend", 0.0
        elif phase == "descend":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0:
                # Straddle the cube's MIDDLE. The bias term cancels the arm's
                # residual droop so the tips land where they were told to.
                goal_pt = cube_p.copy()
                arm_goal, cart_bias = servo_arm(goal_pt, arm_goal, cart_bias)
            # Come in already part-closed. Arriving with the jaws wide open and
            # only then squeezing gives the drifting base time to sweep the hand
            # sideways through the cube and swat it off the bench.
            grip_goal = GRIP_CAGE
            # Separate the tolerances. A plain sphere test fires while the hand is
            # still 5 cm above the cube, and since the fingers are only 5 cm tall
            # they then squeeze shut in the air above it. Height has to be right.
            dxy = float(np.linalg.norm(gc[:2] - cube_p[:2]))
            dz = abs(gc[2] - cube_p[2])
            # Tight. The caged jaws span only +/-0.055, so a 4 cm lateral error
            # can leave the cube outside the pinch and the fingers shut beside it.
            # The base is pinned and the IK is exact to ~2 mm, so 2 cm is available.
            if (dxy < 0.02 and dz < 0.03) or t_phase > 7.0:
                phase, t_phase = "close", 0.0
        elif phase == "close":
            cmd = hold_heading(yaw, WORK_YAW)
            grip_goal = GRIP_CLOSED
            # Latch only after the jaws have finished slewing in (0.37 s at GRIP_RATE),
            # so the cube is sitting between them rather than still being swept toward.
            jaws_in = h1.grip_center()[1] / 2.0 < GRIP_CLOSED + 0.006
            if sg is not None and jaws_in and not sg.is_closed():
                sg.close()
            if (jaws_in and t_phase > 1.2) or t_phase > 4.0:
                grasp_z = cube_p[2]
                grasp_pt = cube_p.copy()
                if use_grip:      # --no-gripper runs the stock class, which has neither
                    held = "closed" if (sg is not None and sg.is_closed()) else "OPEN"
                    print(f"[grip] half-gap {h1.grip_center()[1] / 2.0:.4f} "
                          f"(target {GRIP_CLOSED:.4f}) surface={held}", flush=True)
                phase, t_phase = "lift", 0.0
        elif phase == "lift":
            cmd = hold_heading(yaw, WORK_YAW)
            if use_grip and i % IK_EVERY == 0 and grasp_pt is not None:
                ok, q, _ = h1.solve_arm(grasp_pt + np.array([0.0, 0.0, LIFT_UP]), arm_goal)
                if ok:
                    arm_goal = q
            if t_phase > 2.5:
                phase, t_phase = ("carry" if args.stage == "demo" else "hold"), 0.0
        elif phase == "carry":
            pin = None
            cmd, done = drive_to(base_p[:2], yaw, DROP_XY, 0.25)
            if done:
                phase, t_phase = "hold", 0.0

        # Slew the jaws shut at a finite rate, same reasoning as the arm.
        grip += float(np.clip(grip_goal - grip, -GRIP_RATE * PHYS_DT, GRIP_RATE * PHYS_DT))

        # Slew the arm toward its goal instead of teleporting the target there.
        if args.freeze_arm:
            arm_goal = ARM_HOME
        step = ARM_RATE * PHYS_DT
        arm_q = arm_q + np.clip(arm_goal - arm_q, -step, step)

        # The locomotion policy SWINGS THE ARMS to balance. Overriding the right arm
        # with a scripted pose from t=0 fights that and tips the robot over: measured
        # as a fall at t=4.2 s during 'approach', while the same walk with
        # --no-gripper (policy owns both arms) covered the full 5 m and reached the
        # grasp. Hand the arm over only once we are parked and manipulating, and track
        # the real joint angles until then so the handover does not snap it across.
        manip = phase in ("raise", "reach", "descend", "close", "lift", "carry", "hold")
        if use_grip and not manip:
            arm_q = np.asarray(h1.robot.get_joint_positions()[h1.arm_idx], float)
            arm_goal = arm_q.copy()

        if use_grip:
            h1.forward(PHYS_DT, cmd, arm_q=arm_q if manip else None, grip=grip)
        else:
            h1.forward(PHYS_DT, cmd)          # stock policy signature

        # PIN: hold the pelvis still for the duration of the pick.
        #
        # This is a deliberate simplification, not a physics result. The stock H1
        # locomotion policy cannot hold a pose anywhere near the ~2 cm a wristless
        # 4-DoF arm needs: reaching sideways feeds a yaw moment in and it spins
        # (105 deg measured), drifts, and walks the target out of the arm's reach
        # envelope, at which point IK fails and the hand freezes above the cube.
        # Everything else stays honest -- gravity, contacts, and the fingers
        # gripping the cube by friction are all real, and the walking either side
        # of the pick is the real policy on real physics.
        # ponytail: pinned base during manipulation; the real fix is a
        # loco-manipulation policy co-trained with the arm (see H1-2 work), which
        # is a training job, not a tuning job.
        if pin is not None:
            h1.robot.set_world_pose(pin[0], pin[1])
            h1.robot.set_linear_velocity(np.zeros(3))
            h1.robot.set_angular_velocity(np.zeros(3))
        # Surface_Gripper re-checks its D6 joint against the force/torque limits each
        # tick; without this the attach is never re-evaluated and never breaks.
        if sg is not None:
            sg.update()
        world.step(render=render)
        t_phase += PHYS_DT

        if render:
            frame = np.asarray(cam.get_rgba())
            if frame.ndim == 3 and frame.shape[2] >= 3:
                writer.append_data(frame[:, :, :3])
                frames += 1
            if i % (CAPTURE_EVERY * 25) == 0 or (i < 400 and i % 20 == 0):
                log.append((phase, base_p.copy(), cube_p.copy()))
                extra = ""
                if use_grip:
                    jp = h1.robot.get_joint_positions()
                    jv = h1.robot.get_joint_velocities()
                    print(f"        armT={np.degrees(arm_q).round(1)} armA={np.degrees(jp[h1.arm_idx]).round(1)}"
                          f" fingA={jp[h1.grip_idx].round(4)} fingV={jv[h1.grip_idx].round(2)}"
                          f" armVmax={np.abs(jv[h1.arm_idx]).max():.2f}", flush=True)
                    g, gap = h1.grip_center()
                    tp, tR = h1.torso_frame()
                    pred = tp + tR @ arm_ik.fk(jp[h1.arm_idx], TOOL)[0]
                    print(f"        fk_pred={pred.round(3)} actual={g.round(3)} "
                          f"chain_err={np.linalg.norm(pred - g):.3f}", flush=True)
                    extra = (f" grip=({g[0]:5.2f},{g[1]:5.2f},{g[2]:4.2f}) gap={gap:4.3f}"
                             f" d={np.linalg.norm(g - cube_p):4.3f}"
                             f" surf={'Y' if (sg is not None and sg.is_closed()) else '-'}")
                print(f"  t={i*PHYS_DT:5.1f}s {phase:<9} yaw={np.degrees(yaw):6.1f} base=({base_p[0]:5.2f},{base_p[1]:5.2f},"
                      f"{base_p[2]:4.2f}) cube=({cube_p[0]:5.2f},{cube_p[1]:5.2f},{cube_p[2]:4.2f})"
                      + extra, flush=True)
        if base_p[2] < 0.4:
            print(f"[fail] H1 fell at t={i*PHYS_DT:.1f}s during '{phase}'")
            break

    writer.close()
    cube_end = np.asarray(cube.get_world_pose()[0], float)
    print(f"\n[result] cube {cube_start.round(2)} -> {cube_end.round(2)}, final phase "
          f"'{phase}', {frames} frames -> out/{args.name or args.stage}.mp4", flush=True)

    lifted = cube_end[2] - (TABLE_TOP + CUBE_SIZE / 2)
    moved = float(np.linalg.norm(cube_end[:2] - cube_start[:2]))
    if args.stage == "walk":
        walked = float(np.linalg.norm(np.asarray(base_p[:2]) - np.asarray(WALK_START)))
        assert base_p[2] > 0.6, f"H1 ended up on the floor (pelvis z={base_p[2]:.2f})"
        assert walked > 3.0, f"H1 barely moved ({walked:.2f} m of {abs(WALK_GOAL[0]-WALK_START[0]):.1f})"
        print(f"[ok] walked {walked:.2f} m upright, pelvis z={base_p[2]:.2f}", flush=True)
    elif args.stage == "demo":
        assert lifted > 0.15, f"cube never left the table (rose {lifted:.3f} m)"
        assert moved > 2.0, f"cube was not carried anywhere (moved {moved:.2f} m)"
        print(f"[ok] lifted {lifted:.2f} m, carried {moved:.2f} m", flush=True)
    else:
        # flush: stdout is block-buffered when redirected to a file, and
        # sim_app.close() tears the process down before it drains on its own.
        print(f"[arm] lifted {lifted:.2f} m (want >0.15)", flush=True)
    sim_app.close()


if __name__ == "__main__":
    main()
